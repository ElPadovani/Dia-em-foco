# Dia em Foco

Checklist diário que fica flutuando na área de trabalho do Windows. Você cadastra as atividades
que repete todos os dias, marca o que concluiu e vê em destaque o que passou do horário. A cada
novo dia a lista recomeça sozinha. Funciona 100% offline, sem conta e sem nuvem.

## Funcionalidades
- Widget flutuante, acima das outras janelas (opcional), com posição e tamanho lembrados
- Checklist com progresso do dia ("4 de 8 atividades concluídas"), salvo automaticamente
- Atividades recorrentes: criar, editar, excluir, ordenar, ativar/desativar, horário opcional
- Reinício automático a cada novo dia, mesmo se o app estava fechado ou o PC dormiu
- Alertas de atraso: sem animação, fundo ou borda piscando, ou cor fixa (intensidade e velocidade ajustáveis)
- Cores de fundo e de destaque personalizáveis, com texto sempre legível
- Bandeja do sistema, instância única e início opcional com o Windows

## Requisitos de desenvolvimento
Python 3.12 e Windows 10/11 (64 bits). A lógica de negócio também roda e é testada em Linux/macOS.

## Configurar o ambiente
```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements-dev.txt
```

## Executar em desenvolvimento
```powershell
python main.py
```
Para usar uma pasta de dados separada: `$env:DIA_EM_FOCO_DATA_DIR = "C:\temp\dados"`.

## Testes
```powershell
python -m pytest -q
```
Sem pytest: `python -m unittest discover -s tests -t .`. Os testes de interface (`tests/ui`) precisam
do PySide6 e usam a plataforma `offscreen`; sem ele, são ignorados.

## Gerar o executável e o instalador
Em um Windows com Python e [Inno Setup 6](https://jrsoftware.org/isdl.php):
```powershell
powershell -File scripts\build_windows.ps1
```
Gera `dist\DiaEmFoco\DiaEmFoco.exe` (PyInstaller) e `installer\output\DiaEmFoco-Setup-<versão>.exe`.
Sem Windows local: envie o projeto ao GitHub; o fluxo `.github/workflows/build-windows.yml` roda os
testes, empacota, gera o instalador, instala e desinstala em silêncio, e publica o `.exe` como artefato
para download.

## Onde ficam os dados
`%LOCALAPPDATA%\DiaEmFoco\` (banco `dia_em_foco.db` e `dia_em_foco.log`). Atualizar ou desinstalar o
programa **não** apaga essa pasta. Para remover os dados, exclua-a manualmente.

## Estrutura
`src/dia_em_foco/{data,services,ui}`, `tests/`, `assets/`, `installer/`, `packaging/`, `scripts/`,
`docs/`. Decisões e riscos: [docs/PLANO.md](docs/PLANO.md). Guia do usuário: [docs/USO.md](docs/USO.md).
