# -*- mode: python ; coding: utf-8 -*-
# PyInstaller: gera dist/DiaEmFoco/DiaEmFoco.exe (pasta com o executável e as dependências).
# Uso (no Windows, na raiz do projeto):  pyinstaller packaging/dia_em_foco.spec --noconfirm --clean
#
# Escolha de "onedir" em vez de "onefile": abre mais rápido (não descompacta a cada execução)
# e costuma gerar menos alertas falsos de antivírus. O instalador empacota a pasta inteira.
from pathlib import Path

ROOT = Path(SPECPATH).resolve().parent

# Módulos do Qt que o aplicativo não usa; excluí-los reduz bastante o tamanho do instalador.
UNUSED_QT = [
    "PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets", "PySide6.QtWebEngineQuick",
    "PySide6.Qt3DCore", "PySide6.Qt3DRender", "PySide6.Qt3DInput", "PySide6.Qt3DLogic",
    "PySide6.Qt3DAnimation", "PySide6.Qt3DExtras",
    "PySide6.QtQml", "PySide6.QtQuick", "PySide6.QtQuickWidgets", "PySide6.QtQuick3D",
    "PySide6.QtMultimedia", "PySide6.QtMultimediaWidgets",
    "PySide6.QtCharts", "PySide6.QtDataVisualization", "PySide6.QtGraphs",
    "PySide6.QtSql", "PySide6.QtPdf", "PySide6.QtPdfWidgets", "PySide6.QtDesigner",
    "PySide6.QtBluetooth", "PySide6.QtNfc", "PySide6.QtSensors", "PySide6.QtSerialPort",
    "PySide6.QtPositioning", "PySide6.QtLocation", "PySide6.QtRemoteObjects",
    "PySide6.QtTest", "PySide6.QtHelp", "PySide6.QtSvgWidgets",
]

a = Analysis(
    [str(ROOT / "main.py")],
    pathex=[str(ROOT / "src")],
    binaries=[],
    datas=[(str(ROOT / "assets" / "icon.ico"), "assets")],
    hiddenimports=[],
    hookspath=[],
    runtime_hooks=[],
    excludes=["tkinter", "pytest"] + UNUSED_QT,
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="DiaEmFoco",
    console=False,          # aplicativo de janela: sem console preto
    icon=str(ROOT / "assets" / "icon.ico"),
    upx=False,
    disable_windowed_traceback=False,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name="DiaEmFoco",
)
