"""Configurações do usuário, validadas e persistidas no banco."""

from __future__ import annotations

from dataclasses import dataclass, fields, replace
from typing import Any, Dict, Optional, Tuple

from ..data.repositories import SettingsRepository
from .colors import is_hex_color
from .validation import ValidationError

DEFAULT_BACKGROUND = "#1D2530"
DEFAULT_ACCENT = "#4FB3A9"

ALERT_NONE = "none"
ALERT_BACKGROUND_PULSE = "background_pulse"
ALERT_BORDER_PULSE = "border_pulse"
ALERT_SOLID = "solid"
ALERT_STYLES = (ALERT_NONE, ALERT_BACKGROUND_PULSE, ALERT_BORDER_PULSE, ALERT_SOLID)

MIN_WINDOW_WIDTH = 260
MIN_WINDOW_HEIGHT = 240
MAX_WINDOW_SIZE = 10000


@dataclass(frozen=True)
class Settings:
    background_color: str = DEFAULT_BACKGROUND
    accent_color: str = DEFAULT_ACCENT
    alert_style: str = ALERT_BACKGROUND_PULSE
    alert_intensity: int = 2  # 1 suave, 2 média, 3 forte
    alert_speed: int = 2  # 1 lenta, 2 média, 3 rápida
    always_on_top: bool = True
    start_with_windows: bool = False
    window_geometry: Optional[Tuple[int, int, int, int]] = None  # x, y, largura, altura
    tray_hint_shown: bool = False


# --- conversão de/para texto ---------------------------------------------------------

def _parse_color(value: Any) -> str:
    if not is_hex_color(value):
        raise ValidationError("Cor inválida. Use o formato #RRGGBB.")
    return value.upper()


def _parse_style(value: Any) -> str:
    if value not in ALERT_STYLES:
        raise ValidationError("Estilo de alerta desconhecido.")
    return value


def _parse_level(value: Any) -> int:
    try:
        level = int(value)
    except (TypeError, ValueError):
        raise ValidationError("Valor inválido.") from None
    if level not in (1, 2, 3):
        raise ValidationError("O valor deve ser 1, 2 ou 3.")
    return level


def _parse_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value in ("1", "true", "True"):
        return True
    if value in ("0", "false", "False"):
        return False
    raise ValidationError("Valor inválido.")


def _parse_geometry(value: Any) -> Optional[Tuple[int, int, int, int]]:
    if value is None:
        return None
    try:
        if isinstance(value, str):
            x, y, w, h = (int(p) for p in value.split(","))
        else:
            x, y, w, h = (int(p) for p in value)
    except (TypeError, ValueError):
        raise ValidationError("Geometria da janela inválida.") from None
    if not (MIN_WINDOW_WIDTH <= w <= MAX_WINDOW_SIZE and MIN_WINDOW_HEIGHT <= h <= MAX_WINDOW_SIZE):
        raise ValidationError("Tamanho de janela inválido.")
    if abs(x) > 100000 or abs(y) > 100000:
        raise ValidationError("Posição de janela inválida.")
    return x, y, w, h


_PARSERS = {
    "background_color": _parse_color,
    "accent_color": _parse_color,
    "alert_style": _parse_style,
    "alert_intensity": _parse_level,
    "alert_speed": _parse_level,
    "always_on_top": _parse_bool,
    "start_with_windows": _parse_bool,
    "window_geometry": _parse_geometry,
    "tray_hint_shown": _parse_bool,
}


def _serialize(value: Any) -> str:
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, tuple):
        return ",".join(str(v) for v in value)
    return str(value)


class SettingsService:
    def __init__(self, repo: SettingsRepository) -> None:
        self._repo = repo

    def load(self) -> Settings:
        """Lê as configurações. Valores ausentes ou inválidos voltam ao padrão."""
        stored = self._repo.load_all()
        defaults = Settings()
        values: Dict[str, Any] = {}
        for field in fields(Settings):
            raw = stored.get(field.name)
            if raw is None:
                continue
            try:
                values[field.name] = _PARSERS[field.name](raw)
            except ValidationError:
                values[field.name] = getattr(defaults, field.name)
        return Settings(**values)

    def update(self, **changes: Any) -> Settings:
        """Valida e salva as alterações. Nada é gravado se algum valor for inválido."""
        parsed: Dict[str, Any] = {}
        for name, raw in changes.items():
            if name not in _PARSERS:
                raise ValidationError(f"Configuração desconhecida: {name}")
            parsed[name] = _PARSERS[name](raw)
        to_save = {n: _serialize(v) for n, v in parsed.items() if v is not None}
        to_delete = [n for n, v in parsed.items() if v is None]
        self._repo.save(to_save, to_delete)
        return replace(self.load())

    def reset_colors(self) -> Settings:
        return self.update(background_color=DEFAULT_BACKGROUND, accent_color=DEFAULT_ACCENT)
