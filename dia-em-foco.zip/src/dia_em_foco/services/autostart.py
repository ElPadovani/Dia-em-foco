"""Início automático com o Windows, pela chave HKCU\\...\\Run (não exige administrador).

O backend é injetável para que a lógica possa ser testada fora do Windows.
"""

from __future__ import annotations

import sys
from typing import Optional, Protocol

RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
VALUE_NAME = "DiaEmFoco"


class Backend(Protocol):
    def get(self, name: str) -> Optional[str]: ...
    def set(self, name: str, value: str) -> None: ...
    def delete(self, name: str) -> None: ...


class WindowsRegistryBackend:
    """Lê e grava um valor em HKEY_CURRENT_USER\\...\\Run."""

    def get(self, name: str) -> Optional[str]:
        import winreg

        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_READ) as key:
                value, _ = winreg.QueryValueEx(key, name)
                return str(value)
        except FileNotFoundError:
            return None

    def set(self, name: str, value: str) -> None:
        import winreg

        with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, name, 0, winreg.REG_SZ, value)

    def delete(self, name: str) -> None:
        import winreg

        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
                winreg.DeleteValue(key, name)
        except FileNotFoundError:
            pass


class AutostartManager:
    """Só oferece o recurso no executável instalado (congelado) no Windows."""

    def __init__(self, backend: Optional[Backend] = None, executable: Optional[str] = None) -> None:
        self._backend = backend
        self._executable = executable

    def _get_backend(self) -> Backend:
        if self._backend is None:
            self._backend = WindowsRegistryBackend()
        return self._backend

    def _command(self) -> Optional[str]:
        if self._executable:
            return f'"{self._executable}"'
        if sys.platform == "win32" and getattr(sys, "frozen", False):
            return f'"{sys.executable}"'
        return None

    def is_supported(self) -> bool:
        return self._command() is not None and (self._backend is not None or sys.platform == "win32")

    def is_enabled(self) -> bool:
        return self.is_supported() and self._get_backend().get(VALUE_NAME) is not None

    def enable(self) -> None:
        command = self._command()
        if command is None:
            raise RuntimeError("O início com o Windows só está disponível no aplicativo instalado.")
        self._get_backend().set(VALUE_NAME, command)

    def disable(self) -> None:
        if self._backend is None and sys.platform != "win32":
            return
        self._get_backend().delete(VALUE_NAME)

    def apply_preference(self, enabled: bool) -> None:
        """Alinha o sistema com a preferência salva. Também corrige o caminho se o
        programa foi reinstalado em outra pasta."""
        if not self.is_supported():
            return
        if enabled:
            self.enable()
        else:
            self.disable()
