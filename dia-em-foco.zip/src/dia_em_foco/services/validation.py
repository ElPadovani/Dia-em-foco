"""Validação dos dados digitados pelo usuário."""

from __future__ import annotations

import re
from typing import Optional


class ValidationError(ValueError):
    """Dado inválido informado pelo usuário. A mensagem pode ser exibida na interface."""


MAX_NAME_LENGTH = 80
_TIME_RE = re.compile(r"^(\d{1,2}):(\d{2})$")
_CONTROL_RE = re.compile(r"[\x00-\x1f\x7f]")


def validate_name(raw: str) -> str:
    if raw is None:
        raise ValidationError("Informe o nome da atividade.")
    name = " ".join(_CONTROL_RE.sub(" ", raw).split())
    if not name:
        raise ValidationError("Informe o nome da atividade.")
    if len(name) > MAX_NAME_LENGTH:
        raise ValidationError(f"O nome pode ter no máximo {MAX_NAME_LENGTH} caracteres.")
    return name


def normalize_time(raw: Optional[str]) -> Optional[str]:
    """Converte "9:05" em "09:05". Vazio ou None significa sem horário."""
    if raw is None or not str(raw).strip():
        return None
    match = _TIME_RE.match(str(raw).strip())
    if not match:
        raise ValidationError("Use o horário no formato HH:MM, por exemplo 09:30.")
    hour, minute = int(match.group(1)), int(match.group(2))
    if hour > 23 or minute > 59:
        raise ValidationError("Horário inválido. Use valores de 00:00 a 23:59.")
    return f"{hour:02d}:{minute:02d}"
