"""Cadastro e manutenção das atividades recorrentes."""

from __future__ import annotations

from datetime import datetime
from typing import Callable, List, Optional

from ..data.repositories import ActivityRepository
from ..models import Activity
from .validation import ValidationError, normalize_time, validate_name


class ActivityService:
    def __init__(
        self, repo: ActivityRepository, clock: Callable[[], datetime] = datetime.now
    ) -> None:
        self._repo = repo
        self._clock = clock

    def list_all(self) -> List[Activity]:
        return self._repo.list_all()

    def create(
        self, name: str, scheduled_time: Optional[str] = None, active: bool = True
    ) -> Activity:
        return self._repo.add(
            validate_name(name), normalize_time(scheduled_time), active, self._clock()
        )

    def update(
        self, activity_id: int, name: str, scheduled_time: Optional[str], active: bool
    ) -> Activity:
        if not self._repo.update(
            activity_id, validate_name(name), normalize_time(scheduled_time), active
        ):
            raise ValidationError("Essa atividade não existe mais.")
        activity = self._repo.get(activity_id)
        assert activity is not None
        return activity

    def set_active(self, activity_id: int, active: bool) -> Activity:
        current = self._require(activity_id)
        return self.update(activity_id, current.name, current.scheduled_time, active)

    def delete(self, activity_id: int) -> None:
        if not self._repo.delete(activity_id):
            raise ValidationError("Essa atividade não existe mais.")

    def move(self, activity_id: int, delta: int) -> None:
        """Move a atividade `delta` posições (-1 sobe, +1 desce). Nos limites, não faz nada."""
        ids = [a.id for a in self._repo.list_all()]
        if activity_id not in ids:
            raise ValidationError("Essa atividade não existe mais.")
        index = ids.index(activity_id)
        target = max(0, min(len(ids) - 1, index + delta))
        if target == index:
            return
        ids.insert(target, ids.pop(index))
        self._repo.reorder(ids)

    def _require(self, activity_id: int) -> Activity:
        activity = self._repo.get(activity_id)
        if activity is None:
            raise ValidationError("Essa atividade não existe mais.")
        return activity
