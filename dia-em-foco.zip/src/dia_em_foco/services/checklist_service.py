"""Checklist de um dia: junta atividades ativas, conclusões do dia e atrasos.

O dia e o instante são sempre recebidos como argumentos (nunca lidos aqui),
o que permite simular a virada de data nos testes.
"""

from __future__ import annotations

from datetime import date, datetime
from typing import List, Tuple

from ..data.repositories import ActivityRepository, CompletionRepository
from ..models import ChecklistItem
from .overdue import is_overdue
from .validation import ValidationError


class ChecklistService:
    def __init__(self, activities: ActivityRepository, completions: CompletionRepository) -> None:
        self._activities = activities
        self._completions = completions

    def items(self, day: date, now: datetime) -> List[ChecklistItem]:
        done_ids = self._completions.done_ids(day)
        result = []
        for activity in self._activities.list_active():
            done = activity.id in done_ids
            result.append(
                ChecklistItem(
                    activity=activity,
                    done=done,
                    overdue=is_overdue(activity.scheduled_time, done, now, day),
                )
            )
        return result

    def set_done(self, activity_id: int, day: date, done: bool, now: datetime) -> None:
        activity = self._activities.get(activity_id)
        if activity is None:
            raise ValidationError("Essa atividade não existe mais.")
        if not activity.active:
            raise ValidationError("Essa atividade está desativada.")
        self._completions.set_done(activity_id, day, done, now)

    @staticmethod
    def progress(items: List[ChecklistItem]) -> Tuple[int, int]:
        return sum(1 for i in items if i.done), len(items)
