"""Verificação de geometria salva da janela (por exemplo, monitor desconectado)."""

from __future__ import annotations

from typing import Iterable, Tuple

Rect = Tuple[int, int, int, int]  # x, y, largura, altura


def is_reachable(window: Rect, screens: Iterable[Rect], min_visible: int = 80) -> bool:
    """A janela é alcançável se ao menos `min_visible` px dela (nas duas direções)
    estiverem dentro de algum monitor, o suficiente para o usuário arrastá-la."""
    wx, wy, ww, wh = window
    for sx, sy, sw, sh in screens:
        overlap_w = min(wx + ww, sx + sw) - max(wx, sx)
        overlap_h = min(wy + wh, sy + sh) - max(wy, sy)
        if overlap_w >= min_visible and overlap_h >= min_visible:
            return True
    return False
