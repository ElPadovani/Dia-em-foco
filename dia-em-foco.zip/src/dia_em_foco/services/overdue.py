"""Regra de atraso: uma função pura, fácil de testar."""

from __future__ import annotations

from datetime import date, datetime
from typing import Optional


def is_overdue(
    scheduled_time: Optional[str],
    done: bool,
    now: datetime,
    day: Optional[date] = None,
) -> bool:
    """Uma atividade está atrasada quando tem horário, o minuto atual já passou
    do horário programado e ela não foi concluída.

    Se `day` for informado e não for o dia de `now`, nunca há atraso (o alerta
    só faz sentido no dia corrente).
    """
    if scheduled_time is None or done:
        return False
    if day is not None and day != now.date():
        return False
    hour, minute = (int(part) for part in scheduled_time.split(":"))
    return (now.hour, now.minute) > (hour, minute)
