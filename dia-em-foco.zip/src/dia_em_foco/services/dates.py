"""Textos de data e progresso em português do Brasil (sem depender do idioma do sistema)."""

from __future__ import annotations

from datetime import date

_WEEKDAYS = [
    "segunda-feira", "terça-feira", "quarta-feira", "quinta-feira",
    "sexta-feira", "sábado", "domingo",
]
_MONTHS = [
    "janeiro", "fevereiro", "março", "abril", "maio", "junho",
    "julho", "agosto", "setembro", "outubro", "novembro", "dezembro",
]


def format_long_date(day: date) -> str:
    return f"{_WEEKDAYS[day.weekday()]}, {day.day} de {_MONTHS[day.month - 1]}"


def progress_text(done: int, total: int) -> str:
    if total == 0:
        return "Nenhuma atividade para hoje"
    noun = "atividade concluída" if total == 1 else "atividades concluídas"
    return f"{done} de {total} {noun}"
