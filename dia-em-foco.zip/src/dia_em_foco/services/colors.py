"""Cálculos de cor e contraste (WCAG) usados para manter o texto legível."""

from __future__ import annotations

import re
from typing import Tuple

RGB = Tuple[int, int, int]
_HEX_RE = re.compile(r"^#[0-9a-fA-F]{6}$")


def is_hex_color(value: str) -> bool:
    return isinstance(value, str) and bool(_HEX_RE.match(value))


def parse_hex(color: str) -> RGB:
    if not is_hex_color(color):
        raise ValueError(f"Cor inválida: {color!r}")
    return int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16)


def to_hex(rgb: RGB) -> str:
    r, g, b = (max(0, min(255, round(v))) for v in rgb)
    return f"#{r:02X}{g:02X}{b:02X}"


def luminance(color: str) -> float:
    def channel(v: int) -> float:
        s = v / 255
        return s / 12.92 if s <= 0.03928 else ((s + 0.055) / 1.055) ** 2.4

    r, g, b = parse_hex(color)
    return 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b)


def contrast_ratio(a: str, b: str) -> float:
    la, lb = luminance(a), luminance(b)
    lighter, darker = max(la, lb), min(la, lb)
    return (lighter + 0.05) / (darker + 0.05)


def mix(a: str, b: str, amount: float) -> str:
    """Mistura `a` com `b`: amount=0 devolve `a`, amount=1 devolve `b`."""
    ra, rb = parse_hex(a), parse_hex(b)
    return to_hex(tuple(x * (1 - amount) + y * amount for x, y in zip(ra, rb)))  # type: ignore[arg-type]


LIGHT_TEXT = "#FFFFFF"
DARK_TEXT = "#14181F"  # preto suave, preferido ao preto puro
TEXT_MIN_CONTRAST = 4.5


def readable_text_color(background: str) -> str:
    """Escolhe a cor de texto para o fundo.

    Prefere branco e, depois, o preto suave, desde que alcancem contraste 4,5:1.
    Se nenhum alcançar (fundos cinza médio), usa branco ou preto puros, o que
    tiver maior contraste.
    """
    for candidate in (LIGHT_TEXT, DARK_TEXT):
        if contrast_ratio(candidate, background) >= TEXT_MIN_CONTRAST:
            return candidate
    if contrast_ratio("#FFFFFF", background) >= contrast_ratio("#000000", background):
        return "#FFFFFF"
    return "#000000"


def ensure_contrast(color: str, background: str, minimum: float) -> Tuple[str, bool]:
    """Garante contraste mínimo entre `color` e `background`.

    Devolve (cor, foi_ajustada). A cor é aproximada, aos poucos, do extremo
    (branco ou preto) que mais contrasta com o fundo, preservando o matiz
    enquanto for possível.
    """
    if contrast_ratio(color, background) >= minimum:
        return color, False
    extreme = readable_text_color(background)
    adjusted = color
    for step in range(1, 21):
        adjusted = mix(color, extreme, step / 20)
        if contrast_ratio(adjusted, background) >= minimum:
            break
    return adjusted, True
