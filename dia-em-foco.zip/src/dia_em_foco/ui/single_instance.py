"""Garante uma única instância: a segunda avisa a primeira (que se mostra) e encerra."""

from __future__ import annotations

import getpass
import logging
import re

from PySide6.QtCore import QObject, Signal
from PySide6.QtNetwork import QLocalServer, QLocalSocket

log = logging.getLogger(__name__)


def _instance_name() -> str:
    try:
        user = getpass.getuser()
    except Exception:  # noqa: BLE001 - sem usuário identificável, usa um nome fixo
        user = "usuario"
    return "DiaEmFoco-" + re.sub(r"[^A-Za-z0-9_-]", "_", user)


class SingleInstance(QObject):
    activated = Signal()  # outra instância tentou abrir

    def __init__(self, name: str | None = None, parent=None) -> None:
        super().__init__(parent)
        self._name = name or _instance_name()
        self._server: QLocalServer | None = None

    def try_acquire(self) -> bool:
        """True se esta é a primeira instância. False se já havia outra (e ela foi avisada)."""
        socket = QLocalSocket()
        socket.connectToServer(self._name)
        if socket.waitForConnected(400):
            socket.write(b"show")
            socket.flush()
            socket.waitForBytesWritten(400)
            socket.disconnectFromServer()
            return False

        QLocalServer.removeServer(self._name)  # remove sobra de uma execução que travou
        self._server = QLocalServer(self)
        self._server.newConnection.connect(self._on_connection)
        if not self._server.listen(self._name):
            log.warning("Não foi possível reservar a instância única: %s", self._server.errorString())
        return True

    def _on_connection(self) -> None:
        assert self._server is not None
        while self._server.hasPendingConnections():
            connection = self._server.nextPendingConnection()
            connection.disconnected.connect(connection.deleteLater)
            connection.disconnectFromServer()
            self.activated.emit()
