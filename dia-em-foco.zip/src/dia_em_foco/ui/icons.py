"""Ícone do aplicativo desenhado em código (não depende de arquivos em disco)."""

from __future__ import annotations

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QIcon, QPainter, QPainterPath, QPen, QPixmap

from ..services.settings_service import DEFAULT_ACCENT, DEFAULT_BACKGROUND

_SIZES = (16, 24, 32, 48, 64, 128, 256)


def _draw(size: int) -> QPixmap:
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    margin = size * 0.06
    rect = QRectF(margin, margin, size - 2 * margin, size - 2 * margin)
    painter.setPen(Qt.PenStyle.NoPen)
    painter.setBrush(QColor(DEFAULT_BACKGROUND))
    painter.drawRoundedRect(rect, size * 0.22, size * 0.22)
    # O "visto" em destaque, no centro.
    path = QPainterPath()
    path.moveTo(QPointF(size * 0.26, size * 0.53))
    path.lineTo(QPointF(size * 0.43, size * 0.69))
    path.lineTo(QPointF(size * 0.75, size * 0.33))
    pen = QPen(QColor(DEFAULT_ACCENT), max(2.0, size * 0.12))
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    painter.setPen(pen)
    painter.setBrush(Qt.BrushStyle.NoBrush)
    painter.drawPath(path)
    painter.end()
    return pixmap


def make_app_icon() -> QIcon:
    icon = QIcon()
    for size in _SIZES:
        icon.addPixmap(_draw(size))
    return icon
