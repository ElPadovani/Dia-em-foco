"""Ícone na bandeja do sistema: restaurar a janela ou encerrar o aplicativo."""

from __future__ import annotations

from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QMenu, QSystemTrayIcon


def tray_available() -> bool:
    return QSystemTrayIcon.isSystemTrayAvailable()


class TrayController:
    def __init__(self, window, icon: QIcon) -> None:
        self._window = window
        self.tray = QSystemTrayIcon(icon)
        self.tray.setToolTip("Dia em Foco")

        self._menu = QMenu()  # precisa ser mantido em um atributo, senão é coletado
        show_action = self._menu.addAction("Mostrar Dia em Foco")
        show_action.triggered.connect(window.bring_to_front)
        self._menu.addSeparator()
        quit_action = self._menu.addAction("Sair")
        quit_action.triggered.connect(window.quit_app)
        self.tray.setContextMenu(self._menu)
        self.tray.activated.connect(self._on_activated)
        self.tray.show()

    def _on_activated(self, reason) -> None:
        if reason in (QSystemTrayIcon.ActivationReason.Trigger, QSystemTrayIcon.ActivationReason.DoubleClick):
            if self._window.isVisible() and not self._window.isMinimized():
                self._window.hide()
            else:
                self._window.bring_to_front()
