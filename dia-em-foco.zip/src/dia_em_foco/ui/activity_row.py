"""Uma linha do checklist: caixa de seleção, nome, horário e alerta de atraso."""

from __future__ import annotations

from typing import Tuple

from PySide6.QtCore import QRectF, Qt, Signal
from PySide6.QtGui import QColor, QMouseEvent, QPainter, QPen
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel

from ..models import ChecklistItem
from .theme import Palette
from .widgets import CheckMark, ElidedLabel


class ActivityRow(QFrame):
    toggled = Signal(int, bool)  # id da atividade, novo estado

    def __init__(self, item: ChecklistItem, palette: Palette, parent=None) -> None:
        super().__init__(parent)
        self._activity_id = item.activity.id
        self._palette = palette
        self._overdue = False
        self._effect: Tuple[float, float] = (0.0, 0.0)  # (alfa do fundo, alfa da borda)
        self.setMinimumHeight(40)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 6, 10, 6)
        layout.setSpacing(10)

        self._check = CheckMark()
        self._check.set_colors(palette.accent, palette.border, palette.on_accent)
        self._name = ElidedLabel(item.activity.name)
        self._time = QLabel()
        self._time.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self._name.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self._check.setAccessibleName(item.activity.name)

        layout.addWidget(self._check, 0, Qt.AlignmentFlag.AlignVCenter)
        layout.addWidget(self._name, 1)
        layout.addWidget(self._time, 0, Qt.AlignmentFlag.AlignVCenter)

        self._time_text = item.activity.scheduled_time
        self._check.toggled.connect(self._on_check_toggled)
        self.apply_item(item)

    # --- API usada pela janela principal ---------------------------------------------

    @property
    def activity_id(self) -> int:
        return self._activity_id

    @property
    def is_overdue(self) -> bool:
        return self._overdue

    def check_button(self) -> CheckMark:
        return self._check

    def apply_item(self, item: ChecklistItem) -> None:
        """Atualiza o visual conforme o estado, sem disparar o sinal `toggled`."""
        self._check.blockSignals(True)
        self._check.setChecked(item.done)
        self._check.blockSignals(False)
        self._check.update()

        self._name.set_text_color(self._palette.text_muted if item.done else self._palette.text)
        self._overdue = item.overdue
        if self._time_text:
            if item.overdue:
                self._time.setText(f"Atrasada {self._time_text}")
                self._time.setStyleSheet(f"color: {self._palette.alert}; font-weight: 600;")
                self.setToolTip(f"Atrasada desde {self._time_text}")
            else:
                self._time.setText(self._time_text)
                self._time.setStyleSheet(f"color: {self._palette.text_muted};")
                self.setToolTip("")
            self._time.show()
        else:
            self._time.hide()
        if not item.overdue:
            self._effect = (0.0, 0.0)
        self.update()

    def set_effect(self, fill_alpha: float, border_alpha: float) -> None:
        if (fill_alpha, border_alpha) != self._effect:
            self._effect = (fill_alpha, border_alpha)
            if self._overdue:
                self.update()

    # --- eventos -----------------------------------------------------------------------

    def _on_check_toggled(self, checked: bool) -> None:
        self.toggled.emit(self._activity_id, checked)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        # Clicar em qualquer ponto da linha alterna a atividade.
        if event.button() == Qt.MouseButton.LeftButton and self.rect().contains(event.position().toPoint()):
            self._check.click()
        super().mouseReleaseEvent(event)

    def paintEvent(self, event) -> None:  # noqa: N802
        if not self._overdue:
            return
        fill_alpha, border_alpha = self._effect
        if fill_alpha <= 0 and border_alpha <= 0:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        if fill_alpha > 0:
            fill = QColor(self._palette.alert)
            fill.setAlphaF(min(1.0, fill_alpha))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(fill)
            painter.drawRoundedRect(rect, 8, 8)
        if border_alpha > 0:
            border = QColor(self._palette.alert)
            border.setAlphaF(min(1.0, border_alpha))
            painter.setPen(QPen(border, 2))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawRoundedRect(rect, 8, 8)
