"""Tela de configurações: atividades, aparência e janela."""

from __future__ import annotations

import logging
import sqlite3
from typing import Callable, Optional

from PySide6.QtCore import Qt, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices
from PySide6.QtWidgets import (
    QCheckBox,
    QColorDialog,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from ..context import AppContext
from ..services.settings_service import (
    ALERT_BACKGROUND_PULSE,
    ALERT_BORDER_PULSE,
    ALERT_NONE,
    ALERT_SOLID,
)
from ..services.validation import ValidationError
from .activity_dialog import ActivityDialog
from .theme import build_palette, is_animated

log = logging.getLogger(__name__)

TAB_ACTIVITIES, TAB_APPEARANCE, TAB_WINDOW = 0, 1, 2

_ALERT_LABELS = [
    ("Sem animação", ALERT_NONE),
    ("Fundo piscando suavemente", ALERT_BACKGROUND_PULSE),
    ("Borda piscando", ALERT_BORDER_PULSE),
    ("Cor fixa de alerta", ALERT_SOLID),
]
_INTENSITY_LABELS = [("Suave", 1), ("Média", 2), ("Forte", 3)]
_SPEED_LABELS = [("Lenta", 1), ("Média", 2), ("Rápida", 3)]
_ALERT_HINT = {
    ALERT_NONE: "Sem efeito na linha. A atividade atrasada mostra apenas o texto “Atrasada” e o horário em destaque.",
    ALERT_BACKGROUND_PULSE: "O fundo da atividade atrasada pulsa devagar.",
    ALERT_BORDER_PULSE: "A borda da atividade atrasada pulsa devagar.",
    ALERT_SOLID: "A atividade atrasada fica com uma cor de alerta fixa, sem movimento.",
}


def _combo(options, current) -> QComboBox:
    box = QComboBox()
    for label, value in options:
        box.addItem(label, value)
    box.setCurrentIndex(max(0, box.findData(current)))
    return box


class SettingsDialog(QDialog):
    changed = Signal()  # atividades ou configurações foram alteradas

    def __init__(self, ctx: AppContext, parent: Optional[QWidget] = None, start_tab: int = TAB_ACTIVITIES) -> None:
        super().__init__(parent)
        self._ctx = ctx
        self._loading = False
        self.setWindowTitle("Configurações")
        self.setMinimumSize(480, 440)
        self.resize(520, 480)

        self._tabs = QTabWidget()
        self._tabs.addTab(self._build_activities_tab(), "Atividades")
        self._tabs.addTab(self._build_appearance_tab(), "Aparência")
        self._tabs.addTab(self._build_window_tab(), "Janela")

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.button(QDialogButtonBox.StandardButton.Close).setText("Fechar")
        buttons.rejected.connect(self.accept)
        buttons.accepted.connect(self.accept)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.addWidget(self._tabs, 1)
        layout.addWidget(buttons)

        self._refresh_list()
        self._load_appearance()
        self._load_window()
        self._tabs.setCurrentIndex(start_tab)

    # --- utilidades -----------------------------------------------------------------

    def _guard(self, action: Callable[[], None]) -> bool:
        """Executa uma ação que grava dados, mostrando erros de forma amigável."""
        try:
            action()
        except ValidationError as exc:
            QMessageBox.warning(self, "Dia em Foco", str(exc))
            return False
        except sqlite3.Error:
            log.exception("Falha ao gravar no banco de dados")
            QMessageBox.warning(
                self,
                "Dia em Foco",
                "Não foi possível salvar a alteração. Verifique se há espaço livre no disco e tente novamente.",
            )
            return False
        self.changed.emit()
        return True

    # --- aba Atividades -----------------------------------------------------------------

    def _build_activities_tab(self) -> QWidget:
        page = QWidget()
        self._list = QListWidget()
        self._list.setAccessibleName("Lista de atividades")
        self._list.itemSelectionChanged.connect(self._update_buttons)
        self._list.itemDoubleClicked.connect(lambda _item: self._edit())

        self._btn_add = QPushButton("Adicionar")
        self._btn_add.setProperty("primary", True)
        self._btn_edit = QPushButton("Editar")
        self._btn_toggle = QPushButton("Desativar")
        self._btn_delete = QPushButton("Excluir")
        self._btn_up = QPushButton("Subir")
        self._btn_down = QPushButton("Descer")
        self._btn_add.clicked.connect(self._add)
        self._btn_edit.clicked.connect(self._edit)
        self._btn_toggle.clicked.connect(self._toggle_active)
        self._btn_delete.clicked.connect(self._delete)
        self._btn_up.clicked.connect(lambda: self._move(-1))
        self._btn_down.clicked.connect(lambda: self._move(+1))

        column = QVBoxLayout()
        for button in (self._btn_add, self._btn_edit, self._btn_toggle, self._btn_delete):
            column.addWidget(button)
        column.addSpacing(10)
        column.addWidget(self._btn_up)
        column.addWidget(self._btn_down)
        column.addStretch(1)

        hint = QLabel(
            "As atividades se repetem todos os dias. Desativar esconde a atividade do checklist "
            "sem apagá-la."
        )
        hint.setObjectName("hint")
        hint.setWordWrap(True)

        row = QHBoxLayout()
        row.addWidget(self._list, 1)
        row.addLayout(column)
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 12, 0, 0)
        layout.addLayout(row, 1)
        layout.addWidget(hint)
        return page

    def _selected_id(self) -> Optional[int]:
        item = self._list.currentItem()
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def _refresh_list(self, select_id: Optional[int] = None) -> None:
        if select_id is None:
            select_id = self._selected_id()
        self._list.clear()
        self._activities = self._ctx.activities.list_all()
        for activity in self._activities:
            text = f"{activity.scheduled_time}   {activity.name}" if activity.scheduled_time else activity.name
            if not activity.active:
                text += "   (desativada)"
            item = QListWidgetItem(text)
            item.setData(Qt.ItemDataRole.UserRole, activity.id)
            self._list.addItem(item)
            if activity.id == select_id:
                self._list.setCurrentItem(item)
        self._update_buttons()

    def _update_buttons(self) -> None:
        activity_id = self._selected_id()
        selected = next((a for a in self._activities if a.id == activity_id), None)
        has = selected is not None
        row = self._list.currentRow()
        for button in (self._btn_edit, self._btn_toggle, self._btn_delete):
            button.setEnabled(has)
        self._btn_up.setEnabled(has and row > 0)
        self._btn_down.setEnabled(has and row < self._list.count() - 1)
        self._btn_toggle.setText("Ativar" if has and not selected.active else "Desativar")

    def _add(self) -> None:
        dialog = ActivityDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        name, time_text, active = dialog.values()
        created = []
        if self._guard(lambda: created.append(self._ctx.activities.create(name, time_text, active))):
            self._refresh_list(created[0].id)

    def _edit(self) -> None:
        activity_id = self._selected_id()
        activity = next((a for a in self._activities if a.id == activity_id), None)
        if activity is None:
            return
        dialog = ActivityDialog(self, activity)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        name, time_text, active = dialog.values()
        if self._guard(lambda: self._ctx.activities.update(activity.id, name, time_text, active)):
            self._refresh_list(activity.id)

    def _toggle_active(self) -> None:
        activity_id = self._selected_id()
        activity = next((a for a in self._activities if a.id == activity_id), None)
        if activity is None:
            return
        if self._guard(lambda: self._ctx.activities.set_active(activity.id, not activity.active)):
            self._refresh_list(activity.id)

    def _delete(self) -> None:
        activity_id = self._selected_id()
        activity = next((a for a in self._activities if a.id == activity_id), None)
        if activity is None:
            return
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Icon.Warning)
        box.setWindowTitle("Excluir atividade")
        box.setText(f"Excluir “{activity.name}”?")
        box.setInformativeText(
            "A atividade e o registro das suas conclusões serão apagados. "
            "Para apenas esconder do checklist, use Desativar."
        )
        delete_button = box.addButton("Excluir", QMessageBox.ButtonRole.DestructiveRole)
        cancel_button = box.addButton("Cancelar", QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(cancel_button)
        box.exec()
        if box.clickedButton() is not delete_button:
            return
        row = self._list.currentRow()
        if self._guard(lambda: self._ctx.activities.delete(activity.id)):
            self._refresh_list(select_id=-1)
            if self._list.count():
                self._list.setCurrentRow(min(row, self._list.count() - 1))

    def _move(self, delta: int) -> None:
        activity_id = self._selected_id()
        if activity_id is None:
            return
        if self._guard(lambda: self._ctx.activities.move(activity_id, delta)):
            self._refresh_list(activity_id)

    # --- aba Aparência ------------------------------------------------------------------

    def _build_appearance_tab(self) -> QWidget:
        page = QWidget()
        self._bg_swatch = QLabel()
        self._accent_swatch = QLabel()
        for swatch in (self._bg_swatch, self._accent_swatch):
            swatch.setFixedSize(28, 28)
        self._bg_button = QPushButton("Escolher…")
        self._accent_button = QPushButton("Escolher…")
        self._bg_button.clicked.connect(lambda: self._pick_color("background_color", "Cor de fundo"))
        self._accent_button.clicked.connect(lambda: self._pick_color("accent_color", "Cor de destaque"))
        self._reset_button = QPushButton("Restaurar cores padrão")
        self._reset_button.clicked.connect(self._reset_colors)

        def color_row(swatch: QLabel, button: QPushButton) -> QHBoxLayout:
            row = QHBoxLayout()
            row.addWidget(swatch)
            row.addWidget(button)
            row.addStretch(1)
            return row

        self._contrast_note = QLabel("")
        self._contrast_note.setObjectName("hint")
        self._contrast_note.setWordWrap(True)

        self._alert_style = _combo(_ALERT_LABELS, ALERT_BACKGROUND_PULSE)
        self._alert_intensity = _combo(_INTENSITY_LABELS, 2)
        self._alert_speed = _combo(_SPEED_LABELS, 2)
        self._alert_hint = QLabel("")
        self._alert_hint.setObjectName("hint")
        self._alert_hint.setWordWrap(True)
        self._alert_style.currentIndexChanged.connect(
            lambda _i: self._apply(alert_style=self._alert_style.currentData())
        )
        self._alert_intensity.currentIndexChanged.connect(
            lambda _i: self._apply(alert_intensity=self._alert_intensity.currentData())
        )
        self._alert_speed.currentIndexChanged.connect(
            lambda _i: self._apply(alert_speed=self._alert_speed.currentData())
        )

        form = QFormLayout()
        form.setVerticalSpacing(12)
        form.addRow("Cor de fundo", color_row(self._bg_swatch, self._bg_button))
        form.addRow("Cor de destaque", color_row(self._accent_swatch, self._accent_button))
        form.addRow("", self._reset_button)
        form.addRow("", self._contrast_note)
        form.addRow("Alerta de atraso", self._alert_style)
        form.addRow("", self._alert_hint)
        form.addRow("Intensidade", self._alert_intensity)
        form.addRow("Velocidade", self._alert_speed)

        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 14, 0, 0)
        layout.addLayout(form)
        layout.addStretch(1)
        return page

    def _load_appearance(self) -> None:
        self._loading = True
        try:
            s = self._ctx.settings.load()
            palette = build_palette(s)
            for swatch, color in ((self._bg_swatch, s.background_color), (self._accent_swatch, s.accent_color)):
                swatch.setStyleSheet(f"background-color: {color}; border: 1px solid {palette.border}; border-radius: 6px;")
            self._alert_style.setCurrentIndex(max(0, self._alert_style.findData(s.alert_style)))
            self._alert_intensity.setCurrentIndex(max(0, self._alert_intensity.findData(s.alert_intensity)))
            self._alert_speed.setCurrentIndex(max(0, self._alert_speed.findData(s.alert_speed)))
            self._alert_hint.setText(_ALERT_HINT.get(s.alert_style, ""))
            self._alert_intensity.setEnabled(s.alert_style != ALERT_NONE)
            self._alert_speed.setEnabled(is_animated(s.alert_style))
            if palette.accent_adjusted:
                self._contrast_note.setText(
                    "A cor de destaque tem pouco contraste com o fundo e foi ajustada automaticamente para ficar legível."
                )
            else:
                self._contrast_note.setText("")
        finally:
            self._loading = False

    def _pick_color(self, key: str, title: str) -> None:
        current = getattr(self._ctx.settings.load(), key)
        color = QColorDialog.getColor(QColor(current), self, title)
        if color.isValid():
            self._apply(**{key: color.name().upper()})

    def _reset_colors(self) -> None:
        if self._guard(self._ctx.settings.reset_colors):
            self._load_appearance()

    def _apply(self, **changes) -> None:
        if self._loading:
            return
        if self._guard(lambda: self._ctx.settings.update(**changes)):
            self._load_appearance()

    # --- aba Janela ---------------------------------------------------------------------

    def _build_window_tab(self) -> QWidget:
        page = QWidget()
        self._on_top = QCheckBox("Manter a janela acima das outras")
        self._on_top.toggled.connect(lambda checked: self._apply(always_on_top=checked))

        self._autostart = QCheckBox("Iniciar com o Windows")
        self._autostart.toggled.connect(self._on_autostart)
        self._autostart_hint = QLabel("")
        self._autostart_hint.setObjectName("hint")
        self._autostart_hint.setWordWrap(True)

        tray_hint = QLabel(
            "Ao fechar a janela, o Dia em Foco continua em execução na bandeja do sistema. "
            "Clique no ícone da bandeja para reabrir, ou use o menu dele para encerrar o aplicativo."
        )
        tray_hint.setObjectName("hint")
        tray_hint.setWordWrap(True)

        folder_label = QLabel(str(self._ctx.data_dir))
        folder_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        folder_label.setWordWrap(True)
        open_folder = QPushButton("Abrir pasta dos dados")
        open_folder.clicked.connect(
            lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(self._ctx.data_dir)))
        )
        data_title = QLabel("Seus dados ficam salvos neste computador:")
        data_title.setObjectName("hint")

        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 14, 0, 0)
        layout.setSpacing(10)
        layout.addWidget(self._on_top)
        layout.addWidget(self._autostart)
        layout.addWidget(self._autostart_hint)
        layout.addSpacing(6)
        layout.addWidget(tray_hint)
        layout.addSpacing(6)
        layout.addWidget(data_title)
        layout.addWidget(folder_label)
        layout.addWidget(open_folder, 0, Qt.AlignmentFlag.AlignLeft)
        layout.addStretch(1)
        return page

    def _load_window(self) -> None:
        self._loading = True
        try:
            s = self._ctx.settings.load()
            self._on_top.setChecked(s.always_on_top)
            supported = self._ctx.autostart.is_supported()
            self._autostart.setEnabled(supported)
            self._autostart.setChecked(s.start_with_windows and supported)
            self._autostart_hint.setText(
                "" if supported else "Disponível apenas no aplicativo instalado."
            )
        finally:
            self._loading = False

    def _on_autostart(self, checked: bool) -> None:
        if self._loading:
            return

        def action() -> None:
            self._ctx.autostart.apply_preference(checked)
            self._ctx.settings.update(start_with_windows=checked)

        try:
            ok = self._guard(action)
        except (OSError, RuntimeError):
            log.exception("Falha ao alterar o início automático")
            QMessageBox.warning(self, "Dia em Foco", "Não foi possível alterar o início com o Windows.")
            ok = False
        if not ok:
            self._load_window()
