"""Paleta, folha de estilo (QSS) e parâmetros de alerta.

Este módulo não importa Qt: gera apenas textos e números, o que o torna testável
em qualquer ambiente. A interface aplica o resultado.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Tuple

from ..services.colors import ensure_contrast, mix, readable_text_color
from ..services.settings_service import (
    ALERT_BACKGROUND_PULSE,
    ALERT_BORDER_PULSE,
    ALERT_NONE,
    ALERT_SOLID,
    Settings,
)

ALERT_BASE_COLOR = "#E5484D"
FONT_STACK = '"Segoe UI Variable Text", "Segoe UI", "Helvetica Neue", Arial, sans-serif'


@dataclass(frozen=True)
class Palette:
    background: str
    surface: str       # campos, listas e botões
    border: str
    text: str
    text_muted: str    # textos secundários e atividades concluídas
    accent: str        # já ajustado para contrastar com o fundo
    on_accent: str     # texto sobre a cor de destaque
    alert: str         # já ajustado para contrastar com o fundo
    accent_adjusted: bool
    alert_adjusted: bool


def build_palette(settings: Settings) -> Palette:
    bg = settings.background_color
    text = readable_text_color(bg)
    accent, accent_adjusted = ensure_contrast(settings.accent_color, bg, 3.0)
    alert, alert_adjusted = ensure_contrast(ALERT_BASE_COLOR, bg, 3.0)
    muted = mix(text, bg, 0.32)
    muted, _ = ensure_contrast(muted, bg, 4.5)
    return Palette(
        background=bg,
        surface=mix(bg, text, 0.07),
        border=mix(bg, text, 0.22),
        text=text,
        text_muted=muted,
        accent=accent,
        on_accent=readable_text_color(accent),
        alert=alert,
        accent_adjusted=accent_adjusted,
        alert_adjusted=alert_adjusted,
    )


# --- alertas de atraso ---------------------------------------------------------------

# (alfa mínimo, alfa máximo) do preenchimento, por intensidade 1..3.
_FILL_RANGE = {1: (0.10, 0.22), 2: (0.14, 0.34), 3: (0.20, 0.50)}
# (alfa mínimo, alfa máximo) da borda, por intensidade.
_BORDER_RANGE = {1: (0.30, 0.75), 2: (0.35, 0.90), 3: (0.45, 1.00)}
# Período completo de um pulso, em milissegundos, por velocidade 1..3.
_PERIOD_MS = {1: 3200, 2: 2000, 3: 1200}


def is_animated(style: str) -> bool:
    return style in (ALERT_BACKGROUND_PULSE, ALERT_BORDER_PULSE)


def pulse_period_ms(speed: int) -> int:
    return _PERIOD_MS.get(speed, _PERIOD_MS[2])


def pulse_phase(elapsed_ms: float, period_ms: int) -> float:
    """Oscilação suave de 0 a 1 (senoide), começando em 0."""
    return (1 - math.cos(2 * math.pi * (elapsed_ms % period_ms) / period_ms)) / 2


def alert_alphas(style: str, intensity: int, phase: float) -> Tuple[float, float]:
    """Devolve (alfa do preenchimento, alfa da borda) de uma atividade atrasada.

    - none: nenhum efeito na linha (só o texto "Atrasada" e a cor do horário).
    - solid: cor fixa, sem animação.
    - background_pulse: o preenchimento pulsa; a borda fica discreta.
    - border_pulse: a borda pulsa; o preenchimento fica leve e fixo.
    """
    fill_lo, fill_hi = _FILL_RANGE.get(intensity, _FILL_RANGE[2])
    border_lo, border_hi = _BORDER_RANGE.get(intensity, _BORDER_RANGE[2])
    if style == ALERT_NONE:
        return 0.0, 0.0
    if style == ALERT_SOLID:
        return fill_hi * 0.8, border_hi * 0.8
    if style == ALERT_BACKGROUND_PULSE:
        return fill_lo + (fill_hi - fill_lo) * phase, border_lo * 0.6
    if style == ALERT_BORDER_PULSE:
        return fill_lo * 0.6, border_lo + (border_hi - border_lo) * phase
    return 0.0, 0.0


# --- folha de estilo -----------------------------------------------------------------

def build_stylesheet(p: Palette) -> str:
    return f"""
* {{ font-family: {FONT_STACK}; }}
QWidget {{ background-color: {p.background}; color: {p.text}; font-size: 10pt; }}
QLabel {{ background: transparent; }}
QToolTip {{
    background-color: {p.surface}; color: {p.text};
    border: 1px solid {p.border}; padding: 4px 6px;
}}

QLabel#title {{ font-size: 14pt; font-weight: 600; }}
QLabel#subtitle, QLabel#progressText, QLabel#hint {{ color: {p.text_muted}; }}
QLabel#progressText {{ font-size: 9.5pt; }}
QLabel#error {{ color: {p.alert}; }}

QToolButton#gear {{
    background: transparent; border: 1px solid transparent; border-radius: 6px;
    padding: 4px 8px; font-size: 13pt; color: {p.text_muted};
    font-family: "Segoe UI Symbol", "Segoe UI Emoji", sans-serif;
}}
QToolButton#gear:hover {{ border-color: {p.border}; color: {p.text}; }}
QToolButton#gear:focus {{ border-color: {p.accent}; }}

QProgressBar {{
    background-color: {p.surface}; border: none; border-radius: 3px;
    min-height: 6px; max-height: 6px; text-align: center;
}}
QProgressBar::chunk {{ background-color: {p.accent}; border-radius: 3px; }}

QScrollArea {{ border: none; background: transparent; }}
QScrollArea > QWidget > QWidget {{ background: transparent; }}
QScrollBar:vertical {{ background: transparent; width: 8px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {p.border}; border-radius: 3px; min-height: 24px; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}

QPushButton {{
    background-color: {p.surface}; color: {p.text};
    border: 1px solid {p.border}; border-radius: 6px; padding: 5px 12px;
}}
QPushButton:hover {{ border-color: {p.accent}; }}
QPushButton:focus {{ border-color: {p.accent}; }}
QPushButton:disabled {{ color: {p.text_muted}; border-color: {p.surface}; }}
QPushButton[primary="true"] {{
    background-color: {p.accent}; color: {p.on_accent}; border-color: {p.accent}; font-weight: 600;
}}

QLineEdit, QTimeEdit, QComboBox {{
    background-color: {p.surface}; color: {p.text};
    border: 1px solid {p.border}; border-radius: 6px; padding: 4px 8px;
    selection-background-color: {p.accent}; selection-color: {p.on_accent};
}}
QLineEdit:focus, QTimeEdit:focus, QComboBox:focus {{ border-color: {p.accent}; }}
QComboBox QAbstractItemView {{
    background-color: {p.surface}; color: {p.text}; border: 1px solid {p.border};
    selection-background-color: {p.accent}; selection-color: {p.on_accent};
}}

QListWidget {{
    background-color: {p.surface}; border: 1px solid {p.border}; border-radius: 6px; padding: 2px;
}}
QListWidget::item {{ padding: 6px 8px; border-radius: 4px; }}
QListWidget::item:selected {{ background-color: {p.accent}; color: {p.on_accent}; }}

QTabWidget::pane {{ border: none; border-top: 1px solid {p.border}; top: -1px; }}
QTabBar::tab {{ background: transparent; padding: 7px 14px; color: {p.text_muted}; border-bottom: 2px solid transparent; }}
QTabBar::tab:selected {{ color: {p.text}; border-bottom: 2px solid {p.accent}; }}
QTabBar::tab:hover {{ color: {p.text}; }}

QCheckBox {{ spacing: 8px; }}
QCheckBox::indicator {{
    width: 16px; height: 16px; border: 1px solid {p.border}; border-radius: 4px; background: {p.surface};
}}
QCheckBox::indicator:checked {{ background: {p.accent}; border-color: {p.accent}; }}
QCheckBox:focus {{ color: {p.text}; }}

QMenu {{ background-color: {p.surface}; color: {p.text}; border: 1px solid {p.border}; padding: 4px; }}
QMenu::item {{ padding: 6px 18px; border-radius: 4px; }}
QMenu::item:selected {{ background-color: {p.accent}; color: {p.on_accent}; }}
"""
