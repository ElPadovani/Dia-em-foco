"""Janela para criar ou editar uma atividade."""

from __future__ import annotations

from typing import Optional, Tuple

from PySide6.QtCore import QTime
from PySide6.QtWidgets import (
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QTimeEdit,
    QVBoxLayout,
    QWidget,
)

from ..models import Activity
from ..services.validation import MAX_NAME_LENGTH, ValidationError, validate_name


class ActivityDialog(QDialog):
    def __init__(self, parent: Optional[QWidget] = None, activity: Optional[Activity] = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Editar atividade" if activity else "Nova atividade")
        self.setModal(True)
        self.setMinimumWidth(380)

        self._name = QLineEdit(activity.name if activity else "")
        self._name.setMaxLength(MAX_NAME_LENGTH * 2)  # a validação final é feita ao salvar
        self._name.setPlaceholderText("Por exemplo: Conferir e-mails")

        self._has_time = QCheckBox("Definir horário")
        self._time = QTimeEdit()
        self._time.setDisplayFormat("HH:mm")
        self._time.setEnabled(False)
        if activity and activity.scheduled_time:
            hour, minute = (int(p) for p in activity.scheduled_time.split(":"))
            self._time.setTime(QTime(hour, minute))
            self._has_time.setChecked(True)
            self._time.setEnabled(True)
        else:
            self._time.setTime(QTime(9, 0))
        self._has_time.toggled.connect(self._time.setEnabled)

        time_row = QHBoxLayout()
        time_row.addWidget(self._has_time)
        time_row.addWidget(self._time)
        time_row.addStretch(1)

        self._active = QCheckBox("Mostrar no checklist")
        self._active.setChecked(activity.active if activity else True)

        hint = QLabel("Sem horário, a atividade nunca é marcada como atrasada.")
        hint.setObjectName("hint")
        hint.setWordWrap(True)

        self._error = QLabel("")
        self._error.setObjectName("error")
        self._error.setWordWrap(True)

        form = QFormLayout()
        form.addRow("Nome", self._name)
        form.addRow("Horário", time_row)
        form.addRow("", hint)
        form.addRow("", self._active)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("Salvar")
        buttons.button(QDialogButtonBox.StandardButton.Save).setProperty("primary", True)
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        buttons.accepted.connect(self._on_accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 14)
        layout.setSpacing(10)
        layout.addLayout(form)
        layout.addWidget(self._error)
        layout.addWidget(buttons)
        self._name.setFocus()

    def _on_accept(self) -> None:
        try:
            validate_name(self._name.text())
        except ValidationError as exc:
            self._error.setText(str(exc))
            self._name.setFocus()
            return
        self.accept()

    def values(self) -> Tuple[str, Optional[str], bool]:
        """(nome, horário "HH:MM" ou None, ativa)"""
        time_text = self._time.time().toString("HH:mm") if self._has_time.isChecked() else None
        return self._name.text(), time_text, self._active.isChecked()
