"""Janela principal: o widget flutuante com o checklist do dia."""

from __future__ import annotations

import logging
import sqlite3
from datetime import date, datetime
from typing import Callable, Dict, List, Optional

from PySide6.QtCore import QElapsedTimer, Qt, QTimer
from PySide6.QtGui import QGuiApplication, QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSystemTrayIcon,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from ..context import AppContext
from ..models import ChecklistItem
from ..services.dates import format_long_date, progress_text
from ..services.geometry import is_reachable
from ..services.settings_service import MIN_WINDOW_HEIGHT, MIN_WINDOW_WIDTH, Settings
from ..services.validation import ValidationError
from .activity_row import ActivityRow
from .icons import make_app_icon
from .settings_dialog import TAB_ACTIVITIES, SettingsDialog
from .theme import (
    Palette,
    alert_alphas,
    build_palette,
    build_stylesheet,
    is_animated,
    pulse_period_ms,
    pulse_phase,
)

log = logging.getLogger(__name__)

DEFAULT_SIZE = (340, 480)
TICK_INTERVAL_MS = 10_000   # verifica virada de dia e atrasos
PULSE_INTERVAL_MS = 50      # ~20 quadros por segundo, só enquanto há animação visível
GEOMETRY_SAVE_DELAY_MS = 600


class MainWindow(QMainWindow):
    def __init__(self, ctx: AppContext, clock: Callable[[], datetime] = datetime.now) -> None:
        super().__init__()
        self._ctx = ctx
        self._clock = clock
        self._settings: Settings = ctx.settings.load()
        self._palette: Palette = build_palette(self._settings)
        self._day: date = clock().date()
        self._rows: Dict[int, ActivityRow] = {}
        self._row_order: List[int] = []
        self._last_stylesheet = ""
        self._quitting = False
        self._ready = False
        self.tray: Optional[QSystemTrayIcon] = None  # definido pelo app

        self.setWindowTitle("Dia em Foco")
        self.setWindowIcon(make_app_icon())
        self.setMinimumSize(MIN_WINDOW_WIDTH, MIN_WINDOW_HEIGHT)
        self._build_ui()

        self._tick_timer = QTimer(self)
        self._tick_timer.setInterval(TICK_INTERVAL_MS)
        self._tick_timer.timeout.connect(self._tick)
        self._pulse_timer = QTimer(self)
        self._pulse_timer.setInterval(PULSE_INTERVAL_MS)
        self._pulse_timer.timeout.connect(self._on_pulse)
        self._pulse_clock = QElapsedTimer()
        self._geometry_timer = QTimer(self)
        self._geometry_timer.setSingleShot(True)
        self._geometry_timer.setInterval(GEOMETRY_SAVE_DELAY_MS)
        self._geometry_timer.timeout.connect(self._save_geometry)

        QShortcut(QKeySequence("Ctrl+Q"), self, activated=self.quit_app)

        self._apply_theme()
        self._apply_window_flags()
        self._restore_geometry()
        self.reload()
        self._tick_timer.start()
        self._ready = True

    # --- construção da interface --------------------------------------------------------

    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(16, 14, 16, 12)
        root.setSpacing(10)

        self._title = QLabel("Dia em Foco")
        self._title.setObjectName("title")
        self._subtitle = QLabel("")
        self._subtitle.setObjectName("subtitle")
        titles = QVBoxLayout()
        titles.setSpacing(0)
        titles.addWidget(self._title)
        titles.addWidget(self._subtitle)

        self._gear = QToolButton()
        self._gear.setObjectName("gear")
        self._gear.setText("\u2699")
        self._gear.setToolTip("Configurações")
        self._gear.setAccessibleName("Configurações")
        self._gear.setCursor(Qt.CursorShape.PointingHandCursor)
        self._gear.clicked.connect(lambda: self.open_settings())

        header = QHBoxLayout()
        header.addLayout(titles, 1)
        header.addWidget(self._gear, 0, Qt.AlignmentFlag.AlignTop)
        root.addLayout(header)

        self._progress_label = QLabel("")
        self._progress_label.setObjectName("progressText")
        self._progress_bar = QProgressBar()
        self._progress_bar.setTextVisible(False)
        self._progress_bar.setRange(0, 1)
        root.addWidget(self._progress_label)
        root.addWidget(self._progress_bar)
        root.addSpacing(2)

        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        content = QWidget()
        self._rows_layout = QVBoxLayout(content)
        self._rows_layout.setContentsMargins(0, 0, 0, 0)
        self._rows_layout.setSpacing(2)
        self._scroll.setWidget(content)
        root.addWidget(self._scroll, 1)

    # --- API pública (também usada nos testes) ------------------------------------------

    def row_count(self) -> int:
        return len(self._rows)

    def row_for(self, activity_id: int) -> Optional[ActivityRow]:
        return self._rows.get(activity_id)

    def progress_message(self) -> str:
        return self._progress_label.text()

    def current_day(self) -> date:
        return self._day

    def bring_to_front(self) -> None:
        if self.isMinimized():
            self.showNormal()
        else:
            self.show()
        self.raise_()
        self.activateWindow()

    def open_settings(self, tab: int = TAB_ACTIVITIES) -> None:
        dialog = SettingsDialog(self._ctx, self, start_tab=tab)
        dialog.changed.connect(self._on_settings_changed)
        dialog.exec()

    def quit_app(self) -> None:
        self._quitting = True
        self._save_geometry()
        if self.tray is not None:
            self.tray.hide()
        QApplication.quit()

    # --- carregamento e atualização -----------------------------------------------------

    def reload(self) -> None:
        """Relê o checklist do dia atual e reconstrói as linhas."""
        now = self._clock()
        self._day = now.date()
        try:
            items = self._ctx.checklist.items(self._day, now)
        except sqlite3.Error:
            log.exception("Falha ao ler o checklist")
            items = []
            self._progress_label.setText("Não foi possível ler as atividades")
        self._subtitle.setText(format_long_date(self._day))
        self._rebuild_rows(items)
        self._update_progress(items)
        self._apply_effects(phase=0.0)
        self._sync_animation()

    def _rebuild_rows(self, items: List[ChecklistItem]) -> None:
        while self._rows_layout.count():
            layout_item = self._rows_layout.takeAt(0)
            widget = layout_item.widget()
            if widget is not None:
                widget.setParent(None)
                widget.deleteLater()
        self._rows.clear()
        self._row_order = []

        if not items:
            self._rows_layout.addWidget(self._build_empty_state())
        for item in items:
            row = ActivityRow(item, self._palette)
            row.toggled.connect(self._on_row_toggled)
            self._rows[item.activity.id] = row
            self._row_order.append(item.activity.id)
            self._rows_layout.addWidget(row)
        self._rows_layout.addStretch(1)

    def _build_empty_state(self) -> QWidget:
        box = QWidget()
        layout = QVBoxLayout(box)
        layout.setContentsMargins(0, 24, 0, 0)
        layout.setSpacing(10)
        message = QLabel("Nenhuma atividade ainda. Cadastre as tarefas que você repete todos os dias.")
        message.setObjectName("hint")
        message.setWordWrap(True)
        button = QPushButton("Adicionar atividade")
        button.setProperty("primary", True)
        button.clicked.connect(lambda: self.open_settings())
        layout.addWidget(message)
        layout.addWidget(button, 0, Qt.AlignmentFlag.AlignLeft)
        return box

    def _update_progress(self, items: List[ChecklistItem]) -> None:
        done, total = self._ctx.checklist.progress(items)
        self._progress_label.setText(progress_text(done, total))
        self._progress_bar.setRange(0, max(total, 1))
        self._progress_bar.setValue(done)

    def _refresh_in_place(self, items: List[ChecklistItem]) -> None:
        """Atualiza progresso e atrasos sem recriar as linhas (evita piscar)."""
        for item in items:
            row = self._rows.get(item.activity.id)
            if row is not None:
                row.apply_item(item)
        self._update_progress(items)
        self._apply_effects(phase=self._current_phase())
        self._sync_animation()

    def _tick(self) -> None:
        """Roda a cada poucos segundos: detecta virada de data e novos atrasos."""
        now = self._clock()
        try:
            if now.date() != self._day:
                self.reload()
                return
            items = self._ctx.checklist.items(self._day, now)
        except sqlite3.Error:
            log.exception("Falha ao verificar o checklist")
            return
        if [i.activity.id for i in items] != self._row_order:
            self.reload()
        else:
            self._refresh_in_place(items)

    # --- interação ----------------------------------------------------------------------

    def _on_row_toggled(self, activity_id: int, checked: bool) -> None:
        now = self._clock()
        try:
            self._ctx.checklist.set_done(activity_id, self._day, checked, now)
            items = self._ctx.checklist.items(self._day, now)
        except ValidationError:
            self.reload()
            return
        except sqlite3.Error:
            log.exception("Falha ao salvar a conclusão")
            QMessageBox.warning(
                self,
                "Dia em Foco",
                "Não foi possível salvar essa marcação. Verifique o espaço em disco e tente novamente.",
            )
            self.reload()
            return
        self._refresh_in_place(items)

    def _on_settings_changed(self) -> None:
        self._settings = self._ctx.settings.load()
        self._palette = build_palette(self._settings)
        self._apply_theme()
        self._apply_window_flags()
        self.reload()

    # --- aparência e janela ---------------------------------------------------------------

    def _apply_theme(self) -> None:
        stylesheet = build_stylesheet(self._palette)
        if stylesheet != self._last_stylesheet:
            app = QApplication.instance()
            if app is not None:
                app.setStyleSheet(stylesheet)
            self._last_stylesheet = stylesheet

    def _apply_window_flags(self) -> None:
        wanted = self._settings.always_on_top
        current = bool(self.windowFlags() & Qt.WindowType.WindowStaysOnTopHint)
        if wanted == current:
            return
        was_visible = self.isVisible()
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, wanted)  # esconde a janela
        if was_visible:
            self.show()

    def _screen_rects(self):
        rects = []
        for screen in QGuiApplication.screens():
            g = screen.availableGeometry()
            rects.append((g.x(), g.y(), g.width(), g.height()))
        return rects

    def _restore_geometry(self) -> None:
        saved = self._settings.window_geometry
        if saved and is_reachable(saved, self._screen_rects()):
            self.setGeometry(*saved)
            return
        width, height = DEFAULT_SIZE
        self.resize(width, height)
        primary = QGuiApplication.primaryScreen()
        if primary is not None:
            area = primary.availableGeometry()
            self.move(area.right() - width - 24, area.top() + 60)

    def _save_geometry(self) -> None:
        if not self._ready or self.isMinimized():
            return
        g = self.normalGeometry() if self.isMaximized() else self.geometry()
        try:
            self._ctx.settings.update(window_geometry=(g.x(), g.y(), g.width(), g.height()))
        except (ValidationError, sqlite3.Error):
            log.exception("Não foi possível salvar a posição da janela")

    # --- animação do alerta ---------------------------------------------------------------

    def _overdue_rows(self) -> List[ActivityRow]:
        return [row for row in self._rows.values() if row.is_overdue]

    def _current_phase(self) -> float:
        if not self._pulse_timer.isActive():
            return 0.0
        return pulse_phase(self._pulse_clock.elapsed(), pulse_period_ms(self._settings.alert_speed))

    def _apply_effects(self, phase: float) -> None:
        fill, border = alert_alphas(self._settings.alert_style, self._settings.alert_intensity, phase)
        for row in self._overdue_rows():
            row.set_effect(fill, border)

    def _sync_animation(self) -> None:
        """Liga o relógio de animação só quando há algo atrasado, visível e animado."""
        should_run = (
            is_animated(self._settings.alert_style)
            and bool(self._overdue_rows())
            and self.isVisible()
            and not self.isMinimized()
        )
        if should_run and not self._pulse_timer.isActive():
            self._pulse_clock.start()
            self._pulse_timer.start()
        elif not should_run and self._pulse_timer.isActive():
            self._pulse_timer.stop()

    def _on_pulse(self) -> None:
        self._apply_effects(self._current_phase())

    # --- eventos da janela ----------------------------------------------------------------

    def showEvent(self, event) -> None:  # noqa: N802
        super().showEvent(event)
        self._sync_animation()

    def hideEvent(self, event) -> None:  # noqa: N802
        super().hideEvent(event)
        self._sync_animation()

    def changeEvent(self, event) -> None:  # noqa: N802
        super().changeEvent(event)
        self._sync_animation()

    def moveEvent(self, event) -> None:  # noqa: N802
        super().moveEvent(event)
        if self._ready:
            self._geometry_timer.start()

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        if self._ready:
            self._geometry_timer.start()

    def closeEvent(self, event) -> None:  # noqa: N802
        """Fechar a janela a oculta na bandeja; "Sair" no menu da bandeja encerra o app."""
        if not self._quitting and self.tray is not None and self.tray.isVisible():
            self._save_geometry()
            event.ignore()
            self.hide()
            if not self._settings.tray_hint_shown:
                self.tray.showMessage(
                    "Dia em Foco",
                    "O aplicativo continua em execução na bandeja do sistema. "
                    "Clique no ícone para abrir de novo.",
                    QSystemTrayIcon.MessageIcon.Information,
                    6000,
                )
                try:
                    self._settings = self._ctx.settings.update(tray_hint_shown=True)
                except (ValidationError, sqlite3.Error):
                    log.exception("Não foi possível registrar o aviso da bandeja")
            return
        self._save_geometry()
        event.accept()
