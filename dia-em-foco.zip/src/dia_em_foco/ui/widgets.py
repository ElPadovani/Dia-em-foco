"""Widgets pequenos e próprios: caixa de seleção desenhada e rótulo que corta o texto."""

from __future__ import annotations

from PySide6.QtCore import QPointF, QRectF, QSize, Qt
from PySide6.QtGui import QColor, QFontMetrics, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QAbstractButton, QLabel, QSizePolicy


class CheckMark(QAbstractButton):
    """Caixa de seleção redonda e nítida, com foco visível para o teclado."""

    SIZE = 22

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setCheckable(True)
        self.setFixedSize(self.SIZE, self.SIZE)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self._accent = QColor("#4FB3A9")
        self._border = QColor("#6B7686")
        self._tick = QColor("#FFFFFF")

    def set_colors(self, accent: str, border: str, tick: str) -> None:
        self._accent, self._border, self._tick = QColor(accent), QColor(border), QColor(tick)
        self.update()

    def sizeHint(self) -> QSize:
        return QSize(self.SIZE, self.SIZE)

    def paintEvent(self, event) -> None:  # noqa: N802 (nome definido pelo Qt)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(self.rect()).adjusted(2, 2, -2, -2)
        if self.isChecked():
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(self._accent)
            painter.drawRoundedRect(rect, 6, 6)
            path = QPainterPath()
            path.moveTo(QPointF(rect.left() + rect.width() * 0.25, rect.top() + rect.height() * 0.53))
            path.lineTo(QPointF(rect.left() + rect.width() * 0.43, rect.top() + rect.height() * 0.71))
            path.lineTo(QPointF(rect.left() + rect.width() * 0.76, rect.top() + rect.height() * 0.30))
            pen = QPen(self._tick, 2.2)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
            painter.setPen(pen)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawPath(path)
        else:
            painter.setPen(QPen(self._border, 1.8))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawRoundedRect(rect, 6, 6)
        if self.hasFocus():
            painter.setPen(QPen(self._accent, 1.5, Qt.PenStyle.DotLine))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawRoundedRect(QRectF(self.rect()).adjusted(0.75, 0.75, -0.75, -0.75), 7, 7)


class ElidedLabel(QLabel):
    """Rótulo de uma linha que termina em "…" quando o texto não cabe."""

    def __init__(self, text: str = "", parent=None) -> None:
        super().__init__(parent)
        self._full_text = ""
        self._color = QColor("#FFFFFF")
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.setText(text)

    def setText(self, text: str) -> None:  # noqa: N802
        self._full_text = text
        super().setText(text)
        self.update()

    def set_text_color(self, color: str) -> None:
        self._color = QColor(color)
        self.update()

    def minimumSizeHint(self) -> QSize:  # noqa: N802
        return QSize(20, QFontMetrics(self.font()).height())

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        metrics = QFontMetrics(self.font())
        elided = metrics.elidedText(self._full_text, Qt.TextElideMode.ElideRight, self.width())
        self.setToolTip(self._full_text if elided != self._full_text else "")
        painter.setPen(self._color)
        painter.setFont(self.font())
        painter.drawText(
            self.rect(), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), elided
        )
