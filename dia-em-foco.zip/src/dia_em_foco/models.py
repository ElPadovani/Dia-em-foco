"""Modelos de dados simples compartilhados entre as camadas."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class Activity:
    """Atividade recorrente cadastrada pelo usuário."""

    id: int
    name: str
    scheduled_time: Optional[str]  # "HH:MM" ou None
    active: bool
    position: int


@dataclass(frozen=True)
class ChecklistItem:
    """Uma atividade vista em um dia específico."""

    activity: Activity
    done: bool
    overdue: bool
