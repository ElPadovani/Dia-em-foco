"""Localização dos dados do usuário.

No Windows os dados ficam em %LOCALAPPDATA%\\DiaEmFoco, nunca na pasta de
instalação. A variável DIA_EM_FOCO_DATA_DIR permite redirecionar a pasta
(usada em testes e no desenvolvimento).
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

DATA_DIR_ENV = "DIA_EM_FOCO_DATA_DIR"
FOLDER_NAME = "DiaEmFoco"


def data_dir() -> Path:
    override = os.environ.get(DATA_DIR_ENV)
    if override:
        base = Path(override)
    elif sys.platform == "win32":
        root = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        base = Path(root) / FOLDER_NAME
    else:
        root = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
        base = Path(root) / FOLDER_NAME
    base.mkdir(parents=True, exist_ok=True)
    return base


def database_path() -> Path:
    return data_dir() / "dia_em_foco.db"


def log_path() -> Path:
    return data_dir() / "dia_em_foco.log"
