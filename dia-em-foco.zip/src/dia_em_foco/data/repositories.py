"""Acesso ao banco: atividades, conclusões diárias e configurações.

Todas as escritas usam transações (`with conn:`) e são confirmadas
imediatamente, para que um encerramento inesperado não perca dados.
"""

from __future__ import annotations

import sqlite3
from datetime import date, datetime
from typing import Dict, Iterable, List, Optional, Set

from ..models import Activity


def _activity_from_row(row: sqlite3.Row) -> Activity:
    return Activity(
        id=row["id"],
        name=row["name"],
        scheduled_time=row["scheduled_time"],
        active=bool(row["active"]),
        position=row["position"],
    )


class ActivityRepository:
    def __init__(self, conn: sqlite3.Connection) -> None:
        self._conn = conn

    def list_all(self) -> List[Activity]:
        rows = self._conn.execute("SELECT * FROM activities ORDER BY position, id").fetchall()
        return [_activity_from_row(r) for r in rows]

    def list_active(self) -> List[Activity]:
        rows = self._conn.execute(
            "SELECT * FROM activities WHERE active = 1 ORDER BY position, id"
        ).fetchall()
        return [_activity_from_row(r) for r in rows]

    def get(self, activity_id: int) -> Optional[Activity]:
        row = self._conn.execute(
            "SELECT * FROM activities WHERE id = ?", (activity_id,)
        ).fetchone()
        return _activity_from_row(row) if row else None

    def add(
        self, name: str, scheduled_time: Optional[str], active: bool, created_at: datetime
    ) -> Activity:
        with self._conn:
            position = self._conn.execute(
                "SELECT COALESCE(MAX(position), -1) + 1 FROM activities"
            ).fetchone()[0]
            cursor = self._conn.execute(
                "INSERT INTO activities (name, scheduled_time, active, position, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (name, scheduled_time, int(active), position, created_at.isoformat(timespec="seconds")),
            )
        activity = self.get(cursor.lastrowid)
        assert activity is not None
        return activity

    def update(
        self, activity_id: int, name: str, scheduled_time: Optional[str], active: bool
    ) -> bool:
        with self._conn:
            cursor = self._conn.execute(
                "UPDATE activities SET name = ?, scheduled_time = ?, active = ? WHERE id = ?",
                (name, scheduled_time, int(active), activity_id),
            )
        return cursor.rowcount > 0

    def delete(self, activity_id: int) -> bool:
        with self._conn:
            cursor = self._conn.execute("DELETE FROM activities WHERE id = ?", (activity_id,))
        return cursor.rowcount > 0

    def reorder(self, ordered_ids: Iterable[int]) -> None:
        with self._conn:
            for position, activity_id in enumerate(ordered_ids):
                self._conn.execute(
                    "UPDATE activities SET position = ? WHERE id = ?", (position, activity_id)
                )


class CompletionRepository:
    """Uma linha existe se, e somente se, a atividade foi concluída naquele dia."""

    def __init__(self, conn: sqlite3.Connection) -> None:
        self._conn = conn

    def done_ids(self, day: date) -> Set[int]:
        rows = self._conn.execute(
            "SELECT activity_id FROM completions WHERE day = ?", (day.isoformat(),)
        ).fetchall()
        return {r[0] for r in rows}

    def set_done(self, activity_id: int, day: date, done: bool, at: datetime) -> None:
        with self._conn:
            if done:
                self._conn.execute(
                    "INSERT OR IGNORE INTO completions (activity_id, day, completed_at) "
                    "VALUES (?, ?, ?)",
                    (activity_id, day.isoformat(), at.isoformat(timespec="seconds")),
                )
            else:
                self._conn.execute(
                    "DELETE FROM completions WHERE activity_id = ? AND day = ?",
                    (activity_id, day.isoformat()),
                )

    def count_rows(self) -> int:
        return self._conn.execute("SELECT COUNT(*) FROM completions").fetchone()[0]


class SettingsRepository:
    def __init__(self, conn: sqlite3.Connection) -> None:
        self._conn = conn

    def load_all(self) -> Dict[str, str]:
        rows = self._conn.execute("SELECT key, value FROM settings").fetchall()
        return {r["key"]: r["value"] for r in rows}

    def save(self, values: Dict[str, str], delete_keys: Iterable[str] = ()) -> None:
        with self._conn:
            for key, value in values.items():
                self._conn.execute(
                    "INSERT INTO settings (key, value) VALUES (?, ?) "
                    "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                    (key, value),
                )
            for key in delete_keys:
                self._conn.execute("DELETE FROM settings WHERE key = ?", (key,))
