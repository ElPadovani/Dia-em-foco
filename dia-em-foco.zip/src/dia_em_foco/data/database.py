"""Abertura do banco SQLite, migrações e recuperação de arquivo corrompido."""

from __future__ import annotations

import logging
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple

log = logging.getLogger(__name__)


class NewerDatabaseError(Exception):
    """O banco foi criado por uma versão mais nova do aplicativo."""


# Cada item é uma migração; o índice + 1 é o valor de PRAGMA user_version.
MIGRATIONS = [
    """
    CREATE TABLE activities (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        name           TEXT NOT NULL CHECK (length(trim(name)) > 0),
        scheduled_time TEXT CHECK (
            scheduled_time IS NULL
            OR scheduled_time GLOB '[0-2][0-9]:[0-5][0-9]'
        ),
        active         INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
        position       INTEGER NOT NULL,
        created_at     TEXT NOT NULL
    );
    CREATE TABLE completions (
        activity_id  INTEGER NOT NULL REFERENCES activities(id) ON DELETE CASCADE,
        day          TEXT NOT NULL,
        completed_at TEXT NOT NULL,
        PRIMARY KEY (activity_id, day)
    ) WITHOUT ROWID;
    CREATE INDEX idx_completions_day ON completions(day);
    CREATE TABLE settings (
        key   TEXT PRIMARY KEY,
        value TEXT NOT NULL
    ) WITHOUT ROWID;
    """,
]


def _migrate(conn: sqlite3.Connection) -> None:
    current = conn.execute("PRAGMA user_version").fetchone()[0]
    if current > len(MIGRATIONS):
        raise NewerDatabaseError(
            f"O banco de dados está na versão {current}, mas este aplicativo "
            f"só conhece até a versão {len(MIGRATIONS)}."
        )
    for version in range(current, len(MIGRATIONS)):
        script = f"BEGIN;\n{MIGRATIONS[version]}\nPRAGMA user_version = {version + 1};\nCOMMIT;"
        try:
            conn.executescript(script)
        except sqlite3.Error:
            try:
                conn.execute("ROLLBACK")
            except sqlite3.Error:
                pass
            raise
        log.info("Migração do banco aplicada: versão %d", version + 1)


def open_database(path: Path | str) -> sqlite3.Connection:
    """Abre (e migra, se preciso) o banco. Levanta sqlite3.Error em falhas."""
    conn = sqlite3.connect(str(path), timeout=5.0)
    try:
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        _migrate(conn)
    except BaseException:
        conn.close()
        raise
    return conn


def open_with_recovery(path: Path | str) -> Tuple[sqlite3.Connection, Optional[Path]]:
    """Abre o banco; se o arquivo estiver corrompido, o separa e cria um novo.

    Retorna (conexão, caminho do arquivo separado ou None). Erros que não
    indicam corrupção (banco bloqueado, sem permissão) são repassados, para
    não descartar um arquivo saudável.
    """
    path = Path(path)
    try:
        return open_database(path), None
    except sqlite3.OperationalError:
        raise
    except sqlite3.DatabaseError as exc:
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        backup = path.with_name(f"{path.name}.corrompido-{stamp}")
        log.error("Banco ilegível (%s). Arquivo preservado em %s", exc, backup)
        for suffix in ("", "-wal", "-shm"):
            source = path.with_name(path.name + suffix)
            if source.exists():
                source.replace(backup.with_name(backup.name + suffix))
        return open_database(path), backup
