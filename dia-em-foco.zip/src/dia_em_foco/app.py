"""Inicialização do aplicativo: argumentos, log, banco, interface e bandeja."""

from __future__ import annotations

import argparse
import logging
import logging.handlers
import sqlite3
import sys
from typing import List, Optional

from . import APP_NAME, __version__
from .data import paths
from .data.database import NewerDatabaseError, open_with_recovery

log = logging.getLogger("dia_em_foco")


def _parse_args(argv: List[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(prog="DiaEmFoco", add_help=True)
    parser.add_argument(
        "--remove-autostart",
        action="store_true",
        help="remove o início automático com o Windows e encerra (usado pelo desinstalador)",
    )
    args, _unknown = parser.parse_known_args(argv)  # ignora argumentos do Qt
    return args


def _setup_logging() -> None:
    handlers: List[logging.Handler] = []
    try:
        handlers.append(
            logging.handlers.RotatingFileHandler(
                paths.log_path(), maxBytes=512_000, backupCount=2, encoding="utf-8"
            )
        )
    except OSError:
        pass
    if not getattr(sys, "frozen", False):
        handlers.append(logging.StreamHandler())
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        handlers=handlers,
    )


def _set_windows_app_id() -> None:
    """Faz o Windows agrupar a janela e o ícone da barra de tarefas sob este aplicativo."""
    if sys.platform != "win32":
        return
    try:
        import ctypes

        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("DiaEmFoco.App")
    except Exception:  # noqa: BLE001 - recurso cosmético
        log.debug("Não foi possível definir o AppUserModelID", exc_info=True)


def main(argv: Optional[List[str]] = None) -> int:
    argv = list(sys.argv if argv is None else argv)
    args = _parse_args(argv[1:])

    if args.remove_autostart:
        from .services.autostart import AutostartManager

        AutostartManager().disable()
        return 0

    _setup_logging()
    log.info("%s %s iniciando", APP_NAME, __version__)
    _set_windows_app_id()

    from PySide6.QtCore import QTimer
    from PySide6.QtWidgets import QApplication, QMessageBox

    from .context import build_context
    from .ui.icons import make_app_icon
    from .ui.main_window import MainWindow
    from .ui.single_instance import SingleInstance
    from .ui.tray import TrayController, tray_available

    app = QApplication(argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationDisplayName(APP_NAME)
    app.setWindowIcon(make_app_icon())

    def fatal(message: str) -> int:
        QMessageBox.critical(None, APP_NAME, message)
        return 1

    single = SingleInstance()
    if not single.try_acquire():
        log.info("Já existe uma instância em execução; ela foi avisada.")
        return 0

    try:
        conn, recovered_backup = open_with_recovery(paths.database_path())
    except NewerDatabaseError as exc:
        return fatal(f"{exc}\n\nAtualize o Dia em Foco para a versão mais recente.")
    except (sqlite3.Error, OSError):
        log.exception("Não foi possível abrir o banco de dados")
        return fatal(
            "Não foi possível abrir os dados do Dia em Foco.\n\n"
            f"Pasta dos dados: {paths.data_dir()}\n"
            "Verifique se a pasta existe, se há espaço no disco e se você tem permissão para gravá-la."
        )

    ctx = build_context(conn, paths.data_dir())

    # Mantém o sistema alinhado com a preferência salva (e corrige o caminho após reinstalar).
    try:
        ctx.autostart.apply_preference(ctx.settings.load().start_with_windows)
    except OSError:
        log.exception("Não foi possível aplicar a preferência de início automático")

    window = MainWindow(ctx)
    single.activated.connect(window.bring_to_front)

    tray = None
    if tray_available():
        tray = TrayController(window, make_app_icon())
        window.tray = tray.tray
    app.setQuitOnLastWindowClosed(tray is None)

    def log_uncaught(exc_type, exc, tb) -> None:
        log.critical("Erro não tratado", exc_info=(exc_type, exc, tb))

    sys.excepthook = log_uncaught

    window.show()

    if recovered_backup is not None:
        QTimer.singleShot(
            400,
            lambda: QMessageBox.warning(
                window,
                APP_NAME,
                "O arquivo de dados estava danificado e não pôde ser lido. "
                "Um arquivo novo foi criado; o antigo foi preservado em:\n\n"
                f"{recovered_backup}",
            ),
        )

    code = app.exec()
    conn.close()
    log.info("Encerrado")
    return code
