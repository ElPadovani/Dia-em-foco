"""Dia em Foco: checklist diário flutuante para Windows."""

__version__ = "0.1.0"
APP_NAME = "Dia em Foco"
