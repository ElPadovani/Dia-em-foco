"""Montagem dos serviços do aplicativo (sem Qt), para uso pela interface e pelos testes."""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

from .data.repositories import (
    ActivityRepository,
    CompletionRepository,
    SettingsRepository,
)
from .services.activity_service import ActivityService
from .services.autostart import AutostartManager
from .services.checklist_service import ChecklistService
from .services.settings_service import SettingsService


@dataclass
class AppContext:
    activities: ActivityService
    checklist: ChecklistService
    settings: SettingsService
    autostart: AutostartManager
    data_dir: Path


def build_context(
    conn: sqlite3.Connection,
    data_dir: Path,
    clock: Callable[[], datetime] = datetime.now,
    autostart: Optional[AutostartManager] = None,
) -> AppContext:
    activity_repo = ActivityRepository(conn)
    completion_repo = CompletionRepository(conn)
    return AppContext(
        activities=ActivityService(activity_repo, clock),
        checklist=ChecklistService(activity_repo, completion_repo),
        settings=SettingsService(SettingsRepository(conn)),
        autostart=autostart or AutostartManager(),
        data_dir=data_dir,
    )
