# Dia em Foco: plano técnico

## Entendimento do produto
Um checklist diário pequeno, sempre visível na área de trabalho. O usuário cadastra atividades
recorrentes (com horário opcional), marca as concluídas durante o dia e vê em destaque as que
passaram do horário. A cada novo dia, a lista volta sem marcações. Tudo local, sem conta nem rede.

## Arquitetura
```
main.py ─► app.py ─► ui/ (Qt) ─► services/ (regras) ─► data/ (SQLite)
```
| Camada | Responsabilidade | Depende de Qt? |
|---|---|---|
| `data/` | caminhos, banco, migrações, repositórios | não |
| `services/` | atividades, checklist do dia, atraso, configurações, cores, autostart | não |
| `ui/` | janela flutuante, linhas, diálogos, tema, bandeja, instância única | sim |
| `app.py` | argumentos, log, recuperação do banco, montagem | sim (importado tarde) |

Banco (`PRAGMA user_version` controla as migrações): `activities`, `completions` (chave
`activity_id + day`, impede duplicidade), `settings` (chave/valor).

## MVP e etapas
1. Preparação · 2. Base funcional · 3. Interface principal · 4. Configurações · 5. Alertas ·
6. Estabilização · 7. Distribuição. Etapas 1–2 e as regras das 3–5 têm testes executados;
a interface Qt e a distribuição dependem de validação em Windows (ver README).

## Riscos e decisões
| Risco | Decisão |
|---|---|
| Virada de data com o app aberto, sono do PC ou fechado à meia-noite | Estado ligado à data; verificação a cada 10 s; ao abrir, o dia é recalculado |
| Corrupção do banco | Banco aberto com recuperação: arquivo ruim é preservado como `.corrompido-<data>` e um novo é criado. Erros de bloqueio/permissão não disparam isso |
| Banco de versão futura | Erro claro; o arquivo não é movido |
| Animação consumindo CPU | Um único relógio de 50 ms, só quando há atraso animado e a janela está visível |
| Janela em monitor desconectado | Geometria salva só é usada se ao menos parte dela estiver visível |
| Duas instâncias | Servidor local (QLocalServer); a segunda avisa a primeira e sai |
| Antivírus em executável | `onedir` (não `onefile`), sem UPX |
| Cores com pouco contraste | Texto escolhido por contraste (WCAG); destaque ajustado e usuário avisado |
| Build só funciona em Windows | CI com `windows-latest` gera e testa o instalador |

## Semântica dos estilos de alerta
- **Sem animação**: nenhum efeito na linha; só o texto "Atrasada" e o horário em destaque.
- **Fundo piscando**: o preenchimento pulsa. **Borda piscando**: a borda pulsa.
- **Cor fixa**: preenchimento e borda fixos. Intensidade (1–3) vale para todos; velocidade só para os que pulsam.

## Melhorias futuras (não implementadas)
- Tela de histórico/estatísticas dos dias anteriores (os registros já são mantidos).
- Dias da semana por atividade (hoje todas se repetem todo dia).
- Arrastar para reordenar; atalho global para mostrar/ocultar.
- Assinatura de código do instalador; atualização automática.
