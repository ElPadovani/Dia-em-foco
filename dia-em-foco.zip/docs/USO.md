# Dia em Foco: guia de uso

## Instalar
1. Baixe `DiaEmFoco-Setup-<versão>.exe` e execute. Não precisa de administrador nem de Python.
2. Siga o assistente. Marque "Criar um atalho na área de trabalho" se quiser.
3. Se o Windows exibir "Windows protegeu o computador", clique em **Mais informações** e depois em
   **Executar assim mesmo**. O aviso aparece porque o instalador ainda não tem assinatura digital.

## Cadastrar atividades
Clique na engrenagem (⚙) → aba **Atividades** → **Adicionar**. Informe o nome e, se quiser, marque
**Definir horário**. As atividades se repetem todos os dias. Use **Editar**, **Excluir**, **Subir** e
**Descer**. **Desativar** esconde a atividade do checklist sem apagá-la.

## Marcar como concluída
Clique em qualquer ponto da linha ou na caixa. Clique de novo para desmarcar. Tudo é salvo na hora.
No dia seguinte a lista volta desmarcada.

## Atraso
Uma atividade com horário fica **atrasada** quando o horário passa e ela ainda não foi concluída.
Atividades sem horário nunca ficam atrasadas.

## Personalizar
Engrenagem → **Aparência**: cor de fundo, cor de destaque e estilo do alerta (sem animação, fundo ou
borda piscando, cor fixa), com intensidade e velocidade. Se uma cor ficar ilegível, o aplicativo a
ajusta e avisa. **Janela**: manter acima das outras e iniciar com o Windows (só no app instalado).

## Janela e bandeja
Arraste pela barra de título; redimensione pelas bordas. Posição e tamanho são lembrados. Fechar a
janela (X) a deixa na **bandeja do sistema** (perto do relógio). Clique no ícone para reabrir; botão
direito → **Sair** para encerrar. Abrir o programa de novo apenas traz a janela de volta.

## Problemas comuns
- **A janela sumiu**: clique no ícone da bandeja (talvez em "Mostrar ícones ocultos", ^).
- **Não inicia com o Windows**: ative em Configurações → Janela (disponível só no app instalado).
- **Aviso de "dados danificados"**: o arquivo antigo foi preservado ao lado do novo, na pasta
  `%LOCALAPPDATA%\DiaEmFoco`, com final `.corrompido-…`.
- **Dados e registro de erros**: `%LOCALAPPDATA%\DiaEmFoco` (Configurações → Janela → Abrir pasta dos dados).
