﻿\xef\xbb\xbf; Instalador do Dia em Foco (Inno Setup 6.3 ou superior).
; Compilar:  iscc /DMyAppVersion=0.1.0 installer\DiaEmFoco.iss
; Saída:     installer\output\DiaEmFoco-Setup-<versão>.exe
; Antes de compilar, gere a pasta dist\DiaEmFoco com o PyInstaller.

#define MyAppName "Dia em Foco"
#ifndef MyAppVersion
  #define MyAppVersion "0.1.0"
#endif
#define MyAppExeName "DiaEmFoco.exe"

[Setup]
; Não altere o AppId: é ele que permite atualizar a instalação existente.
AppId={{9871D4BE-9292-463E-BFD5-078ED943967D}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppName}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
; Instala só para o usuário atual, sem pedir administrador. O usuário pode escolher
; "para todos os usuários" no diálogo, se desejar.
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
OutputDir=output
OutputBaseFilename=DiaEmFoco-Setup-{#MyAppVersion}
SetupIconFile=..\assets\icon.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
; O PySide6 só existe para 64 bits.
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
; Fecha o aplicativo se estiver aberto durante uma atualização ou desinstalação.
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "..\dist\DiaEmFoco\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#MyAppName}}"; Flags: nowait postinstall skipifsilent

[UninstallRun]
; Remove o início automático com o Windows, caso o usuário o tenha ativado.
Filename: "{app}\{#MyAppExeName}"; Parameters: "--remove-autostart"; Flags: runhidden; RunOnceId: "RemoveAutostart"

; Os dados do usuário ficam em %LOCALAPPDATA%\DiaEmFoco e NÃO são listados em
; [InstallDelete] nem [UninstallDelete]: atualizar ou desinstalar não os apaga.

[Code]
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if (CurUninstallStep = usDone) and (not UninstallSilent) then
    MsgBox('O Dia em Foco foi removido.' + #13#10#13#10 +
           'Suas atividades e configurações foram mantidas em:' + #13#10 +
           ExpandConstant('{localappdata}\DiaEmFoco') + #13#10#13#10 +
           'Para apagá-las, exclua essa pasta.', mbInformation, MB_OK);
end;
