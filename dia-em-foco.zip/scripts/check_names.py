"""Verificação estática simples: nomes usados mas nunca definidos/importados no módulo.

Não substitui um linter (pyflakes/ruff), mas pega erros de digitação quando
ferramentas externas não estão disponíveis. Uso: python scripts/check_names.py
"""

import ast
import builtins
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def defined_names(tree: ast.AST) -> set:
    names = set(dir(builtins)) | {"__file__", "__name__", "__doc__"}
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            for alias in node.names:
                names.add((alias.asname or alias.name).split(".")[0])
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(node.name)
            if not isinstance(node, ast.ClassDef):
                a = node.args
                for arg in a.posonlyargs + a.args + a.kwonlyargs:
                    names.add(arg.arg)
                if a.vararg:
                    names.add(a.vararg.arg)
                if a.kwarg:
                    names.add(a.kwarg.arg)
        elif isinstance(node, ast.Lambda):
            a = node.args
            for arg in a.posonlyargs + a.args + a.kwonlyargs:
                names.add(arg.arg)
        elif isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Del)):
            names.add(node.id)
        elif isinstance(node, ast.ExceptHandler) and node.name:
            names.add(node.name)
        elif isinstance(node, ast.arg):
            names.add(node.arg)
    return names


def main() -> int:
    problems = 0
    for path in sorted((ROOT / "src").rglob("*.py")) + [ROOT / "main.py"]:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        known = defined_names(tree)
        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load) and node.id not in known:
                print(f"{path.relative_to(ROOT)}:{node.lineno}: nome indefinido: {node.id}")
                problems += 1
    print("OK: nenhum nome indefinido" if not problems else f"{problems} problema(s)")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
