# Gera o executavel (PyInstaller) e o instalador (Inno Setup) do Dia em Foco.
# Executar no Windows, a partir de qualquer pasta:  powershell -File scripts\build_windows.ps1
param(
    [switch]$SkipTests,
    [switch]$SkipInstaller
)
$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
Set-Location $root

function Run($exe, $arguments) {
    & $exe @arguments
    if ($LASTEXITCODE -ne 0) { throw "Falhou: $exe $($arguments -join ' ') (codigo $LASTEXITCODE)" }
}

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    Write-Host "== Criando ambiente virtual =="
    Run "python" @("-m", "venv", ".venv")
}
$py = Join-Path $root ".venv\Scripts\python.exe"

Write-Host "== Instalando dependencias =="
Run $py @("-m", "pip", "install", "--upgrade", "pip")
Run $py @("-m", "pip", "install", "-r", "requirements-dev.txt")

if (-not $SkipTests) {
    Write-Host "== Executando testes =="
    $env:QT_QPA_PLATFORM = "offscreen"
    Run $py @("-m", "pytest", "-q")
}

Write-Host "== Empacotando com PyInstaller =="
Run $py @("-m", "PyInstaller", "packaging\dia_em_foco.spec", "--noconfirm", "--clean")
if (-not (Test-Path "dist\DiaEmFoco\DiaEmFoco.exe")) { throw "dist\DiaEmFoco\DiaEmFoco.exe nao foi gerado" }

if ($SkipInstaller) { Write-Host "Executavel pronto em dist\DiaEmFoco"; exit 0 }

Write-Host "== Gerando instalador com Inno Setup =="
$version = (& $py -c "import sys; sys.path.insert(0, 'src'); from dia_em_foco import __version__; print(__version__)").Trim()
$candidates = @(
    (Get-Command iscc -ErrorAction SilentlyContinue | ForEach-Object { $_.Source }),
    "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
    "$env:ProgramFiles\Inno Setup 6\ISCC.exe",
    "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe"
) | Where-Object { $_ -and (Test-Path $_) }
if (-not $candidates) { throw "Inno Setup 6 nao encontrado. Instale em https://jrsoftware.org/isdl.php" }
Run $candidates[0] @("/DMyAppVersion=$version", "installer\DiaEmFoco.iss")
Write-Host "Instalador pronto em installer\output"
