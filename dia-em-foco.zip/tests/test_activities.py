from datetime import date, datetime

from tests.support import AppTestCase
from dia_em_foco.services.validation import ValidationError

DAY = date(2026, 10, 22)
NOW = datetime(2026, 10, 22, 8, 0)


class ActivityTests(AppTestCase):
    def test_01_cadastro_aparece_no_checklist(self):
        self.ctx.activities.create("Conferir e-mails", "09:00")
        items = self.ctx.checklist.items(DAY, NOW)
        self.assertEqual([i.activity.name for i in items], ["Conferir e-mails"])
        self.assertEqual(items[0].activity.scheduled_time, "09:00")
        self.assertFalse(items[0].done)

    def test_horario_e_normalizado_e_opcional(self):
        a = self.ctx.activities.create("A", "9:05")
        b = self.ctx.activities.create("B")
        c = self.ctx.activities.create("C", "")
        self.assertEqual(a.scheduled_time, "09:05")
        self.assertIsNone(b.scheduled_time)
        self.assertIsNone(c.scheduled_time)

    def test_validacao_de_nome_e_horario(self):
        for bad in ("", "   ", "x" * 81):
            with self.assertRaises(ValidationError):
                self.ctx.activities.create(bad)
        for bad in ("25:00", "10:60", "abc", "9"):
            with self.assertRaises(ValidationError):
                self.ctx.activities.create("Ok", bad)
        self.assertEqual(self.ctx.activities.list_all(), [])

    def test_nome_tem_espacos_normalizados(self):
        a = self.ctx.activities.create("  Revisar \n  prioridades  ")
        self.assertEqual(a.name, "Revisar prioridades")

    def test_11_editar(self):
        a = self.ctx.activities.create("Relatório", "16:00")
        b = self.ctx.activities.update(a.id, "Atualizar relatório", None, True)
        self.assertEqual((b.name, b.scheduled_time), ("Atualizar relatório", None))

    def test_11_excluir_e_inexistente(self):
        a = self.ctx.activities.create("Temporária")
        self.ctx.activities.delete(a.id)
        self.assertEqual(self.ctx.activities.list_all(), [])
        with self.assertRaises(ValidationError):
            self.ctx.activities.delete(a.id)
        with self.assertRaises(ValidationError):
            self.ctx.activities.update(a.id, "x", None, True)

    def test_11_desativar_esconde_sem_apagar_dados(self):
        a = self.ctx.activities.create("Planejar amanhã", "17:00")
        self.ctx.checklist.set_done(a.id, DAY, True, NOW)
        self.ctx.activities.set_active(a.id, False)
        self.assertEqual(self.ctx.checklist.items(DAY, NOW), [])
        self.assertEqual(len(self.ctx.activities.list_all()), 1)
        # Reativar traz a atividade de volta, inclusive a conclusão já registrada.
        self.ctx.activities.set_active(a.id, True)
        items = self.ctx.checklist.items(DAY, NOW)
        self.assertEqual(len(items), 1)
        self.assertTrue(items[0].done)

    def test_atividade_desativada_nao_pode_ser_marcada(self):
        a = self.ctx.activities.create("X")
        self.ctx.activities.set_active(a.id, False)
        with self.assertRaises(ValidationError):
            self.ctx.checklist.set_done(a.id, DAY, True, NOW)

    def test_11_ordenacao_e_persistencia_da_ordem(self):
        a, b, c = (self.ctx.activities.create(n) for n in "ABC")
        self.ctx.activities.move(c.id, -1)   # A C B
        self.ctx.activities.move(a.id, +1)   # C A B
        names = [x.name for x in self.ctx.activities.list_all()]
        self.assertEqual(names, ["C", "A", "B"])
        self.ctx.activities.move(c.id, -1)   # já é o primeiro: nada muda
        self.ctx.activities.move(b.id, +1)   # já é o último: nada muda
        self.assertEqual([x.name for x in self.ctx.activities.list_all()], ["C", "A", "B"])
        ctx = self.reopen_app()
        self.assertEqual([x.name for x in ctx.activities.list_all()], ["C", "A", "B"])
        self.assertEqual([i.activity.name for i in ctx.checklist.items(DAY, NOW)], ["C", "A", "B"])

    def test_novas_atividades_entram_no_fim(self):
        self.ctx.activities.create("A")
        b = self.ctx.activities.create("B")
        self.ctx.activities.move(b.id, -1)
        self.ctx.activities.create("C")
        self.assertEqual([x.name for x in self.ctx.activities.list_all()], ["B", "A", "C"])


if __name__ == "__main__":
    import unittest
    unittest.main()
