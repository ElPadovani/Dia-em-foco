import unittest

from tests.support import AppTestCase
from dia_em_foco.services.autostart import AutostartManager, VALUE_NAME
from dia_em_foco.services.colors import (
    contrast_ratio, ensure_contrast, mix, readable_text_color,
)
from dia_em_foco.services.geometry import is_reachable
from tests.support import FakeAutostartBackend


class ColorTests(unittest.TestCase):
    def test_contraste_preto_e_branco(self):
        self.assertAlmostEqual(contrast_ratio("#000000", "#FFFFFF"), 21.0, places=1)

    def test_texto_legivel_em_qualquer_fundo(self):
        for bg in ("#000000", "#1D2530", "#777777", "#CCCCCC", "#FFFFFF", "#FFFF00", "#0000FF"):
            text = readable_text_color(bg)
            self.assertGreaterEqual(contrast_ratio(text, bg), 4.5, msg=bg)

    def test_baixo_contraste_e_ajustado(self):
        color, adjusted = ensure_contrast("#222A36", "#1D2530", 3.0)
        self.assertTrue(adjusted)
        self.assertGreaterEqual(contrast_ratio(color, "#1D2530"), 3.0)

    def test_contraste_suficiente_nao_e_alterado(self):
        color, adjusted = ensure_contrast("#4FB3A9", "#1D2530", 3.0)
        self.assertEqual((color, adjusted), ("#4FB3A9", False))

    def test_mix(self):
        self.assertEqual(mix("#000000", "#FFFFFF", 0.5), "#808080")
        self.assertEqual(mix("#102030", "#FFFFFF", 0), "#102030")


class GeometryTests(unittest.TestCase):
    SCREENS = [(0, 0, 1920, 1080)]

    def test_janela_dentro_da_tela(self):
        self.assertTrue(is_reachable((100, 100, 340, 460), self.SCREENS))

    def test_janela_em_monitor_desconectado(self):
        self.assertFalse(is_reachable((2500, 100, 340, 460), self.SCREENS))

    def test_janela_minimizada_do_windows(self):
        self.assertFalse(is_reachable((-32000, -32000, 340, 460), self.SCREENS))

    def test_janela_quase_toda_fora_mas_com_parte_visivel(self):
        self.assertTrue(is_reachable((1850, 100, 340, 460), self.SCREENS, min_visible=60))
        self.assertFalse(is_reachable((1900, 100, 340, 460), self.SCREENS))

    def test_segundo_monitor(self):
        screens = self.SCREENS + [(1920, 0, 1280, 1024)]
        self.assertTrue(is_reachable((2500, 100, 340, 460), screens))


class AutostartTests(unittest.TestCase):
    def test_ativar_desativar_e_corrigir_caminho(self):
        backend = FakeAutostartBackend()
        manager = AutostartManager(backend=backend, executable=r"C:\Apps\DiaEmFoco.exe")
        self.assertTrue(manager.is_supported())
        self.assertFalse(manager.is_enabled())
        manager.enable()
        self.assertEqual(backend.values[VALUE_NAME], r'"C:\Apps\DiaEmFoco.exe"')
        self.assertTrue(manager.is_enabled())
        # Reinstalado em outra pasta: a preferência salva corrige o caminho.
        AutostartManager(backend=backend, executable=r"D:\Novo\DiaEmFoco.exe").apply_preference(True)
        self.assertEqual(backend.values[VALUE_NAME], r'"D:\Novo\DiaEmFoco.exe"')
        manager.apply_preference(False)
        self.assertFalse(manager.is_enabled())

    def test_nao_suportado_fora_do_executavel_instalado(self):
        manager = AutostartManager(backend=FakeAutostartBackend())  # sem executável, sem sys.frozen
        self.assertFalse(manager.is_supported())
        self.assertFalse(manager.is_enabled())
        with self.assertRaises(RuntimeError):
            manager.enable()
        manager.apply_preference(True)  # não faz nada, não quebra


if __name__ == "__main__":
    unittest.main()
