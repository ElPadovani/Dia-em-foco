"""Testes da interface (PySide6, plataforma "offscreen").

São ignorados automaticamente se o PySide6 não estiver instalado. Rodam no CI do
Windows e em qualquer máquina de desenvolvimento com as dependências instaladas.
"""

import os
import unittest
from datetime import datetime

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

try:
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QApplication

    HAVE_QT = True
except ImportError:  # pragma: no cover
    HAVE_QT = False

from tests.support import AppTestCase


@unittest.skipUnless(HAVE_QT, "PySide6 não está instalado")
class MainWindowTests(AppTestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def make_window(self, now=datetime(2026, 10, 22, 8, 0)):
        from dia_em_foco.ui.main_window import MainWindow

        self.now = now
        window = MainWindow(self.ctx, clock=lambda: self.now)
        self.addCleanup(window.deleteLater)
        return window

    def test_lista_atividades_ativas_e_progresso(self):
        self.ctx.activities.create("Conferir e-mails", "09:00")
        b = self.ctx.activities.create("Oculta")
        self.ctx.activities.set_active(b.id, False)
        self.ctx.activities.create("Revisar tarefas")
        window = self.make_window()
        self.assertEqual(window.row_count(), 2)
        self.assertEqual(window.progress_message(), "0 de 2 atividades concluídas")

    def test_marcar_atualiza_progresso_e_persiste(self):
        a = self.ctx.activities.create("Conferir e-mails")
        self.ctx.activities.create("Revisar tarefas")
        window = self.make_window()
        window.row_for(a.id).check_button().click()
        self.assertEqual(window.progress_message(), "1 de 2 atividades concluídas")
        ctx = self.reopen_app()
        items = ctx.checklist.items(self.now.date(), self.now)
        self.assertEqual([i.done for i in items], [True, False])
        window.row_for(a.id).check_button().click()  # desmarcar
        self.assertEqual(window.progress_message(), "0 de 2 atividades concluídas")

    def test_virada_de_dia_com_o_app_aberto(self):
        a = self.ctx.activities.create("Conferir e-mails")
        window = self.make_window()
        window.row_for(a.id).check_button().click()
        self.assertEqual(window.progress_message(), "1 de 1 atividade concluída")
        self.now = datetime(2026, 10, 23, 0, 0, 5)
        window._tick()
        self.assertEqual(window.current_day().day, 23)
        self.assertEqual(window.progress_message(), "0 de 1 atividade concluída")
        self.assertFalse(window.row_for(a.id).check_button().isChecked())

    def test_atraso_aparece_e_some_ao_concluir(self):
        a = self.ctx.activities.create("Conferir e-mails", "09:00")
        b = self.ctx.activities.create("Sem horário")
        window = self.make_window(datetime(2026, 10, 22, 10, 0))
        self.assertTrue(window.row_for(a.id).is_overdue)
        self.assertFalse(window.row_for(b.id).is_overdue)
        window.row_for(a.id).check_button().click()
        self.assertFalse(window.row_for(a.id).is_overdue)

    def test_tick_detecta_novo_atraso(self):
        a = self.ctx.activities.create("Conferir e-mails", "09:00")
        window = self.make_window(datetime(2026, 10, 22, 8, 59))
        self.assertFalse(window.row_for(a.id).is_overdue)
        self.now = datetime(2026, 10, 22, 9, 1)
        window._tick()
        self.assertTrue(window.row_for(a.id).is_overdue)

    def test_sempre_acima_segue_a_configuracao(self):
        self.ctx.settings.update(always_on_top=False)
        window = self.make_window()
        self.assertFalse(bool(window.windowFlags() & Qt.WindowType.WindowStaysOnTopHint))
        self.ctx.settings.update(always_on_top=True)
        window._on_settings_changed()
        self.assertTrue(bool(window.windowFlags() & Qt.WindowType.WindowStaysOnTopHint))

    def test_padrao_e_ficar_acima_das_outras(self):
        window = self.make_window()
        self.assertTrue(bool(window.windowFlags() & Qt.WindowType.WindowStaysOnTopHint))

    def test_tamanho_e_posicao_sao_restaurados(self):
        window = self.make_window()
        window.setGeometry(50, 60, 400, 500)
        window._save_geometry()
        self.assertEqual(self.ctx.settings.load().window_geometry, (50, 60, 400, 500))
        again = self.make_window()
        g = again.geometry()
        self.assertEqual((g.x(), g.y(), g.width(), g.height()), (50, 60, 400, 500))

    def test_geometria_em_monitor_inexistente_e_ignorada(self):
        self.ctx.settings.update(window_geometry=(9000, 9000, 400, 500))
        window = self.make_window()
        self.assertNotEqual(window.geometry().x(), 9000)

    def test_estado_vazio(self):
        window = self.make_window()
        self.assertEqual(window.row_count(), 0)
        self.assertEqual(window.progress_message(), "Nenhuma atividade para hoje")

    def test_configuracoes_lista_atividades(self):
        from dia_em_foco.ui.settings_dialog import SettingsDialog

        self.ctx.activities.create("A", "09:00")
        self.ctx.activities.create("B")
        dialog = SettingsDialog(self.ctx)
        self.addCleanup(dialog.deleteLater)
        self.assertEqual(dialog._list.count(), 2)


if __name__ == "__main__":
    unittest.main()
