import sqlite3
import unittest
from pathlib import Path
import tempfile
import shutil

from dia_em_foco.data.database import (
    MIGRATIONS, NewerDatabaseError, open_database, open_with_recovery,
)
from tests.support import AppTestCase  # garante sys.path


class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="diaemfoco-db-"))
        self.addCleanup(shutil.rmtree, self.tmp, ignore_errors=True)
        self.path = self.tmp / "x.db"

    def test_cria_esquema_e_versao(self):
        conn = open_database(self.path)
        self.assertEqual(conn.execute("PRAGMA user_version").fetchone()[0], len(MIGRATIONS))
        tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertTrue({"activities", "completions", "settings"} <= tables)
        self.assertEqual(conn.execute("PRAGMA foreign_keys").fetchone()[0], 1)
        conn.close()

    def test_abrir_duas_vezes_nao_refaz_migracao(self):
        open_database(self.path).close()
        conn = open_database(self.path)
        self.assertEqual(conn.execute("PRAGMA user_version").fetchone()[0], len(MIGRATIONS))
        conn.close()

    def test_banco_de_versao_mais_nova_nao_e_tratado_como_corrompido(self):
        conn = open_database(self.path)
        conn.execute(f"PRAGMA user_version = {len(MIGRATIONS) + 5}")
        conn.close()
        with self.assertRaises(NewerDatabaseError):
            open_with_recovery(self.path)
        self.assertTrue(self.path.exists())  # o arquivo não foi movido

    def test_arquivo_corrompido_e_preservado_e_um_novo_e_criado(self):
        self.path.write_bytes(b"isto nao e um banco sqlite " * 200)
        conn, backup = open_with_recovery(self.path)
        self.assertIsNotNone(backup)
        self.assertTrue(backup.exists())
        self.assertEqual(backup.read_bytes()[:12], b"isto nao e u")
        self.assertEqual(conn.execute("SELECT COUNT(*) FROM activities").fetchone()[0], 0)
        conn.close()

    def test_conclusoes_nao_duplicam_por_chave_primaria(self):
        conn = open_database(self.path)
        with conn:
            conn.execute("INSERT INTO activities (name, position, created_at) VALUES ('A', 0, 'x')")
            conn.execute("INSERT INTO completions VALUES (1, '2026-10-22', 'x')")
        with self.assertRaises(sqlite3.IntegrityError):
            with conn:
                conn.execute("INSERT INTO completions VALUES (1, '2026-10-22', 'y')")
        conn.close()

    def test_excluir_atividade_remove_suas_conclusoes(self):
        conn = open_database(self.path)
        with conn:
            conn.execute("INSERT INTO activities (name, position, created_at) VALUES ('A', 0, 'x')")
            conn.execute("INSERT INTO completions VALUES (1, '2026-10-22', 'x')")
            conn.execute("DELETE FROM activities WHERE id = 1")
        self.assertEqual(conn.execute("SELECT COUNT(*) FROM completions").fetchone()[0], 0)
        conn.close()


if __name__ == "__main__":
    unittest.main()
