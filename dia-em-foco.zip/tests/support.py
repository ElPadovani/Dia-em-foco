"""Utilitários compartilhados pelos testes."""

from __future__ import annotations

import os
import shutil
import sys
import tempfile
import unittest
from datetime import datetime
from pathlib import Path

SRC = Path(__file__).resolve().parents[1] / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from dia_em_foco.context import AppContext, build_context  # noqa: E402
from dia_em_foco.data.database import open_database  # noqa: E402
from dia_em_foco.services.autostart import AutostartManager  # noqa: E402


class FakeAutostartBackend:
    def __init__(self) -> None:
        self.values = {}

    def get(self, name):
        return self.values.get(name)

    def set(self, name, value):
        self.values[name] = value

    def delete(self, name):
        self.values.pop(name, None)


class AppTestCase(unittest.TestCase):
    """Cria uma pasta temporária e permite "fechar e reabrir" o aplicativo."""

    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp(prefix="diaemfoco-test-"))
        self.addCleanup(shutil.rmtree, self.tmp, ignore_errors=True)
        self.db_path = self.tmp / "teste.db"
        self._conns = []
        self.ctx = self.open_app()

    def open_app(self) -> AppContext:
        conn = open_database(self.db_path)
        self._conns.append(conn)
        return build_context(
            conn,
            self.tmp,
            clock=lambda: datetime(2026, 10, 22, 8, 0),
            autostart=AutostartManager(backend=FakeAutostartBackend(), executable="C:/x/DiaEmFoco.exe"),
        )

    def reopen_app(self) -> AppContext:
        """Simula fechar o aplicativo e abri-lo de novo."""
        for conn in self._conns:
            conn.close()
        self._conns.clear()
        self.ctx = self.open_app()
        return self.ctx

    def tearDown(self) -> None:
        for conn in self._conns:
            conn.close()
