import unittest

from tests.support import AppTestCase
from dia_em_foco.services.settings_service import Settings
from dia_em_foco.services.validation import ValidationError


class SettingsTests(AppTestCase):
    def test_padroes_na_primeira_execucao(self):
        s = self.ctx.settings.load()
        self.assertEqual(s, Settings())
        self.assertTrue(s.always_on_top)
        self.assertIsNone(s.window_geometry)

    def test_09_personalizacao_persiste_apos_reabrir(self):
        self.ctx.settings.update(
            background_color="#ffffff",
            accent_color="#aa3366",
            alert_style="border_pulse",
            alert_intensity=3,
            alert_speed=1,
            always_on_top=False,
            window_geometry=(120, 80, 360, 520),
        )
        s = self.reopen_app().settings.load()
        self.assertEqual(s.background_color, "#FFFFFF")
        self.assertEqual(s.accent_color, "#AA3366")
        self.assertEqual(s.alert_style, "border_pulse")
        self.assertEqual((s.alert_intensity, s.alert_speed), (3, 1))
        self.assertFalse(s.always_on_top)
        self.assertEqual(s.window_geometry, (120, 80, 360, 520))

    def test_valores_invalidos_sao_rejeitados_sem_gravar_nada(self):
        antes = self.ctx.settings.load()
        casos = [
            {"background_color": "vermelho"},
            {"accent_color": "#12345"},
            {"alert_style": "piscar_muito"},
            {"alert_intensity": 9},
            {"alert_speed": "rapidíssimo"},
            {"always_on_top": "talvez"},
            {"window_geometry": (0, 0, 10, 10)},
            {"inexistente": 1},
        ]
        for caso in casos:
            with self.assertRaises(ValidationError, msg=str(caso)):
                self.ctx.settings.update(**caso)
        # Uma alteração válida junto com uma inválida não grava nem a válida.
        with self.assertRaises(ValidationError):
            self.ctx.settings.update(accent_color="#FF0000", alert_speed=7)
        self.assertEqual(self.ctx.settings.load(), antes)

    def test_valor_corrompido_no_banco_volta_ao_padrao(self):
        self.ctx.settings.update(accent_color="#FF0000", alert_intensity=3)
        conn = self._conns[-1]
        with conn:
            conn.execute("UPDATE settings SET value = 'lixo' WHERE key = 'accent_color'")
        s = self.reopen_app().settings.load()
        self.assertEqual(s.accent_color, Settings().accent_color)
        self.assertEqual(s.alert_intensity, 3)

    def test_geometria_pode_ser_removida(self):
        self.ctx.settings.update(window_geometry=(1, 2, 300, 400))
        self.ctx.settings.update(window_geometry=None)
        self.assertIsNone(self.ctx.settings.load().window_geometry)

    def test_restaurar_cores_padrao(self):
        self.ctx.settings.update(background_color="#000000", accent_color="#FFFFFF")
        s = self.ctx.settings.reset_colors()
        self.assertEqual((s.background_color, s.accent_color), (Settings().background_color, Settings().accent_color))


if __name__ == "__main__":
    unittest.main()
