from datetime import date, datetime, timedelta

from tests.support import AppTestCase
from dia_em_foco.services.dates import format_long_date, progress_text

D1 = date(2026, 10, 22)
D2 = date(2026, 10, 23)
NOW1 = datetime(2026, 10, 22, 8, 0)
NOW2 = datetime(2026, 10, 23, 0, 0, 5)


class ChecklistTests(AppTestCase):
    def setUp(self):
        super().setUp()
        self.a = self.ctx.activities.create("Conferir e-mails", "09:00")
        self.b = self.ctx.activities.create("Revisar tarefas", "09:30")
        self.c = self.ctx.activities.create("Organizar a mesa")

    def done_names(self, ctx, day, now):
        return [i.activity.name for i in ctx.checklist.items(day, now) if i.done]

    def test_02_conclusao_atualiza_progresso(self):
        items = self.ctx.checklist.items(D1, NOW1)
        self.assertEqual(self.ctx.checklist.progress(items), (0, 3))
        self.ctx.checklist.set_done(self.a.id, D1, True, NOW1)
        items = self.ctx.checklist.items(D1, NOW1)
        self.assertEqual(self.ctx.checklist.progress(items), (1, 3))
        self.ctx.checklist.set_done(self.a.id, D1, False, NOW1)
        self.assertEqual(self.ctx.checklist.progress(self.ctx.checklist.items(D1, NOW1)), (0, 3))

    def test_marcar_duas_vezes_nao_duplica(self):
        self.ctx.checklist.set_done(self.a.id, D1, True, NOW1)
        self.ctx.checklist.set_done(self.a.id, D1, True, NOW1)
        self.assertEqual(self.done_names(self.ctx, D1, NOW1), ["Conferir e-mails"])

    def test_03_persistencia_no_mesmo_dia(self):
        self.ctx.checklist.set_done(self.a.id, D1, True, NOW1)
        self.ctx.checklist.set_done(self.c.id, D1, True, NOW1)
        ctx = self.reopen_app()
        self.assertEqual(self.done_names(ctx, D1, NOW1), ["Conferir e-mails", "Organizar a mesa"])

    def test_04_virada_de_data_zera_o_progresso(self):
        for act in (self.a, self.b, self.c):
            self.ctx.checklist.set_done(act.id, D1, True, NOW1)
        self.assertEqual(self.ctx.checklist.progress(self.ctx.checklist.items(D1, NOW1)), (3, 3))
        novo_dia = self.ctx.checklist.items(D2, NOW2)
        self.assertEqual(len(novo_dia), 3)
        self.assertEqual(self.ctx.checklist.progress(novo_dia), (0, 3))
        self.assertFalse(any(i.done for i in novo_dia))

    def test_04_app_fechado_na_virada_identifica_novo_dia_ao_abrir(self):
        self.ctx.checklist.set_done(self.a.id, D1, True, NOW1)
        ctx = self.reopen_app()
        self.assertEqual(ctx.checklist.progress(ctx.checklist.items(D2, NOW2)), (0, 3))

    def test_05_virada_de_data_preserva_atividades_e_configuracoes(self):
        self.ctx.settings.update(accent_color="#FF8800", alert_style="solid")
        before = self.ctx.activities.list_all()
        self.ctx.checklist.set_done(self.a.id, D1, True, NOW1)
        self.ctx.checklist.items(D2, NOW2)
        ctx = self.reopen_app()
        self.assertEqual(ctx.activities.list_all(), before)
        self.assertEqual(ctx.settings.load().accent_color, "#FF8800")
        self.assertEqual(ctx.settings.load().alert_style, "solid")

    def test_registros_anteriores_sao_preservados(self):
        self.ctx.checklist.set_done(self.a.id, D1, True, NOW1)
        self.ctx.checklist.set_done(self.a.id, D2, True, NOW2)
        # Desmarcar hoje não mexe no registro de ontem.
        self.ctx.checklist.set_done(self.a.id, D2, False, NOW2)
        self.assertEqual(self.done_names(self.ctx, D1, NOW1), ["Conferir e-mails"])
        self.assertEqual(self.done_names(self.ctx, D2, NOW2), [])

    def test_alterar_uma_atividade_nao_apaga_progresso_das_outras(self):
        self.ctx.checklist.set_done(self.b.id, D1, True, NOW1)
        self.ctx.activities.update(self.a.id, "Novo nome", "10:00", True)
        self.ctx.activities.set_active(self.c.id, False)
        self.ctx.activities.delete(self.c.id)
        self.assertEqual(self.done_names(self.ctx, D1, NOW1), ["Revisar tarefas"])

    def test_textos_em_portugues(self):
        self.assertEqual(format_long_date(D1), "quinta-feira, 22 de outubro")
        self.assertEqual(format_long_date(date(2026, 3, 1)), "domingo, 1 de março")
        self.assertEqual(progress_text(4, 8), "4 de 8 atividades concluídas")
        self.assertEqual(progress_text(1, 1), "1 de 1 atividade concluída")
        self.assertEqual(progress_text(0, 0), "Nenhuma atividade para hoje")


if __name__ == "__main__":
    import unittest
    unittest.main()
