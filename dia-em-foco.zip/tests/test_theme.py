import unittest

from tests.support import AppTestCase  # garante sys.path
from dia_em_foco.services.colors import contrast_ratio
from dia_em_foco.services.settings_service import Settings
from dia_em_foco.ui.theme import (
    alert_alphas, build_palette, build_stylesheet, is_animated, pulse_period_ms, pulse_phase,
)


class PaletteTests(unittest.TestCase):
    def test_paleta_padrao_e_legivel(self):
        p = build_palette(Settings())
        self.assertGreaterEqual(contrast_ratio(p.text, p.background), 4.5)
        self.assertGreaterEqual(contrast_ratio(p.text_muted, p.background), 4.5)
        self.assertGreaterEqual(contrast_ratio(p.accent, p.background), 3.0)
        self.assertGreaterEqual(contrast_ratio(p.on_accent, p.accent), 4.5)
        self.assertFalse(p.accent_adjusted)

    def test_varias_combinacoes_continuam_legiveis(self):
        fundos = ["#000000", "#1D2530", "#777777", "#F4F4F4", "#FFFFFF", "#FFFF00", "#2200AA"]
        destaques = ["#4FB3A9", "#FF0000", "#222222", "#EEEEEE", "#777777"]
        for bg in fundos:
            for ac in destaques:
                p = build_palette(Settings(background_color=bg, accent_color=ac))
                self.assertGreaterEqual(contrast_ratio(p.text, bg), 4.5, msg=(bg, ac))
                self.assertGreaterEqual(contrast_ratio(p.accent, bg), 3.0, msg=(bg, ac))
                self.assertGreaterEqual(contrast_ratio(p.alert, bg), 3.0, msg=(bg, ac))
                self.assertGreaterEqual(contrast_ratio(p.text_muted, bg), 4.5, msg=(bg, ac))

    def test_destaque_com_baixo_contraste_e_sinalizado(self):
        p = build_palette(Settings(background_color="#1D2530", accent_color="#222A36"))
        self.assertTrue(p.accent_adjusted)

    def test_estilo_contem_as_cores_e_chaves_balanceadas(self):
        p = build_palette(Settings())
        qss = build_stylesheet(p)
        self.assertIn(p.background, qss)
        self.assertIn(p.accent, qss)
        self.assertEqual(qss.count("{"), qss.count("}"))


class AlertTests(unittest.TestCase):
    def test_sem_animacao_nao_desenha_efeito(self):
        self.assertEqual(alert_alphas("none", 3, 1.0), (0.0, 0.0))

    def test_cor_fixa_nao_depende_da_fase(self):
        self.assertEqual(alert_alphas("solid", 2, 0.0), alert_alphas("solid", 2, 1.0))
        self.assertGreater(alert_alphas("solid", 2, 0.0)[0], 0)

    def test_fundo_pulsa_e_borda_pulsa(self):
        f0, _ = alert_alphas("background_pulse", 2, 0.0)
        f1, _ = alert_alphas("background_pulse", 2, 1.0)
        self.assertGreater(f1, f0)
        _, b0 = alert_alphas("border_pulse", 2, 0.0)
        _, b1 = alert_alphas("border_pulse", 2, 1.0)
        self.assertGreater(b1, b0)

    def test_intensidade_aumenta_o_efeito(self):
        suave = alert_alphas("background_pulse", 1, 1.0)[0]
        forte = alert_alphas("background_pulse", 3, 1.0)[0]
        self.assertGreater(forte, suave)

    def test_alfas_sempre_entre_0_e_1(self):
        for style in ("none", "solid", "background_pulse", "border_pulse"):
            for intensity in (1, 2, 3):
                for phase in (0.0, 0.3, 1.0):
                    for alpha in alert_alphas(style, intensity, phase):
                        self.assertTrue(0.0 <= alpha <= 1.0)

    def test_fase_e_periodo(self):
        self.assertAlmostEqual(pulse_phase(0, 2000), 0.0)
        self.assertAlmostEqual(pulse_phase(1000, 2000), 1.0)
        self.assertAlmostEqual(pulse_phase(2000, 2000), 0.0)
        self.assertGreater(pulse_period_ms(1), pulse_period_ms(2))
        self.assertGreater(pulse_period_ms(2), pulse_period_ms(3))

    def test_quais_estilos_animam(self):
        self.assertTrue(is_animated("background_pulse"))
        self.assertTrue(is_animated("border_pulse"))
        self.assertFalse(is_animated("solid"))
        self.assertFalse(is_animated("none"))


if __name__ == "__main__":
    unittest.main()
