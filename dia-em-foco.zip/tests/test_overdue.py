import unittest
from datetime import date, datetime

from tests.support import AppTestCase
from dia_em_foco.services.overdue import is_overdue

D = date(2026, 10, 22)


def at(h, m, s=0):
    return datetime(2026, 10, 22, h, m, s)


class OverdueRuleTests(unittest.TestCase):
    def test_antes_do_horario_nao_atrasa(self):
        self.assertFalse(is_overdue("09:00", False, at(8, 59, 59)))

    def test_no_proprio_minuto_ainda_nao_atrasa(self):
        self.assertFalse(is_overdue("09:00", False, at(9, 0, 30)))

    def test_depois_do_horario_atrasa(self):
        self.assertTrue(is_overdue("09:00", False, at(9, 1)))
        self.assertTrue(is_overdue("09:00", False, at(23, 59)))

    def test_08_sem_horario_nunca_atrasa(self):
        self.assertFalse(is_overdue(None, False, at(23, 59)))

    def test_concluida_nao_atrasa(self):
        self.assertFalse(is_overdue("09:00", True, at(15, 0)))

    def test_so_atrasa_no_dia_corrente(self):
        self.assertFalse(is_overdue("09:00", False, at(15, 0), day=date(2026, 10, 21)))
        self.assertTrue(is_overdue("09:00", False, at(15, 0), day=D))


class OverdueIntegrationTests(AppTestCase):
    def test_06_detecta_atraso_no_checklist(self):
        self.ctx.activities.create("Conferir e-mails", "09:00")
        antes = self.ctx.checklist.items(D, at(8, 30))
        depois = self.ctx.checklist.items(D, at(9, 30))
        self.assertFalse(antes[0].overdue)
        self.assertTrue(depois[0].overdue)

    def test_07_concluir_atividade_atrasada_remove_o_alerta(self):
        a = self.ctx.activities.create("Conferir e-mails", "09:00")
        self.assertTrue(self.ctx.checklist.items(D, at(10, 0))[0].overdue)
        self.ctx.checklist.set_done(a.id, D, True, at(10, 0))
        self.assertFalse(self.ctx.checklist.items(D, at(10, 0))[0].overdue)
        # Desmarcar de novo faz o atraso voltar.
        self.ctx.checklist.set_done(a.id, D, False, at(10, 1))
        self.assertTrue(self.ctx.checklist.items(D, at(10, 1))[0].overdue)

    def test_08_atividade_sem_horario_nao_e_atrasada(self):
        self.ctx.activities.create("Organizar a mesa")
        self.assertFalse(self.ctx.checklist.items(D, at(23, 59))[0].overdue)

    def test_alterar_horario_reavalia_o_atraso(self):
        a = self.ctx.activities.create("Relatório", "09:00")
        self.assertTrue(self.ctx.checklist.items(D, at(10, 0))[0].overdue)
        self.ctx.activities.update(a.id, "Relatório", "16:00", True)
        self.assertFalse(self.ctx.checklist.items(D, at(10, 0))[0].overdue)
        self.ctx.activities.update(a.id, "Relatório", None, True)
        self.assertFalse(self.ctx.checklist.items(D, at(23, 0))[0].overdue)

    def test_desativar_atividade_atrasada_remove_do_checklist(self):
        a = self.ctx.activities.create("Relatório", "09:00")
        self.ctx.activities.set_active(a.id, False)
        self.assertEqual(self.ctx.checklist.items(D, at(10, 0)), [])


if __name__ == "__main__":
    unittest.main()
