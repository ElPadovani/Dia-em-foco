# Dia em Foco: instruções permanentes de desenvolvimento

Checklist diário flutuante para Windows. Python + PySide6 + SQLite, empacotado com
PyInstaller e Inno Setup. Idioma da interface e da documentação: português do Brasil.

## Decisões já tomadas (não refazer sem motivo)
- Lógica de negócio em `src/dia_em_foco/services` e `data`: **sem importar Qt**. Qt só em `ui/` e `app.py`.
- Data e hora entram como argumento (`day`, `now`); nunca ler o relógio dentro das regras. Facilita testes.
- Estado de conclusão = uma linha em `completions (activity_id, day)`. Virar o dia não apaga nada.
- Atraso: tem horário, o minuto atual passou do horário, não concluída, e só no dia corrente.
- Dados em `%LOCALAPPDATA%\DiaEmFoco` (`DIA_EM_FOCO_DATA_DIR` redireciona). Nunca na pasta de instalação.
- Fechar a janela oculta na bandeja; "Sair" no menu da bandeja encerra. Sem bandeja, fechar encerra.
- Sem transparência, janela sem borda, som, notificações do Windows, rede ou atualização automática.
- Instalador por usuário (sem administrador); desinstalar nunca apaga os dados.
- PyInstaller em modo onedir; o `.iss` precisa ficar em UTF-8 com BOM.
- Migrações: acrescentar itens em `MIGRATIONS` (data/database.py). Nunca editar uma já publicada.

## Comandos
- Testes: `python -m pytest -q` (ou `python -m unittest discover -s tests -t .` sem pytest).
- Rodar: `python main.py`
- Verificação de nomes sem linter: `python scripts/check_names.py`
- Build no Windows: `powershell -File scripts\build_windows.ps1`

## Regras de trabalho
- Mudança incremental; cada etapa validada com testes antes da seguinte.
- Nunca declarar teste aprovado sem execução real. Separar "implementado", "testado" e "pendente em Windows".
- Ideias fora do escopo vão para `docs/PLANO.md` (seção "Melhorias futuras"), sem implementar.
